
_kill:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
#include "stat.h"
#include "user.h"

int
main(int argc, char **argv)
{
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	push   -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	57                   	push   %edi
   e:	56                   	push   %esi
   f:	53                   	push   %ebx
  10:	bb 01 00 00 00       	mov    $0x1,%ebx
  15:	51                   	push   %ecx
  16:	83 ec 08             	sub    $0x8,%esp
  19:	8b 31                	mov    (%ecx),%esi
  1b:	8b 79 04             	mov    0x4(%ecx),%edi
  int i;

  if(argc < 2){
  1e:	83 fe 01             	cmp    $0x1,%esi
  21:	7e 27                	jle    4a <main+0x4a>
  23:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  27:	90                   	nop
    printf(2, "usage: kill pid...\n");
    exit();
  }
  for(i=1; i<argc; i++)
    kill(atoi(argv[i]));
  28:	83 ec 0c             	sub    $0xc,%esp
  2b:	ff 34 9f             	push   (%edi,%ebx,4)
  for(i=1; i<argc; i++)
  2e:	83 c3 01             	add    $0x1,%ebx
    kill(atoi(argv[i]));
  31:	e8 0a 02 00 00       	call   240 <atoi>
  36:	89 04 24             	mov    %eax,(%esp)
  39:	e8 a5 02 00 00       	call   2e3 <kill>
  for(i=1; i<argc; i++)
  3e:	83 c4 10             	add    $0x10,%esp
  41:	39 de                	cmp    %ebx,%esi
  43:	75 e3                	jne    28 <main+0x28>
  exit();
  45:	e8 69 02 00 00       	call   2b3 <exit>
    printf(2, "usage: kill pid...\n");
  4a:	50                   	push   %eax
  4b:	50                   	push   %eax
  4c:	68 c4 09 00 00       	push   $0x9c4
  51:	6a 02                	push   $0x2
  53:	e8 b8 03 00 00       	call   410 <printf>
    exit();
  58:	e8 56 02 00 00       	call   2b3 <exit>
  5d:	66 90                	xchg   %ax,%ax
  5f:	90                   	nop

00000060 <strcpy>:
#include "user.h"
#include "x86.h"

char*
strcpy(char *s, const char *t)
{
  60:	55                   	push   %ebp
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  61:	31 c0                	xor    %eax,%eax
{
  63:	89 e5                	mov    %esp,%ebp
  65:	53                   	push   %ebx
  66:	8b 4d 08             	mov    0x8(%ebp),%ecx
  69:	8b 5d 0c             	mov    0xc(%ebp),%ebx
  6c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  while((*s++ = *t++) != 0)
  70:	0f b6 14 03          	movzbl (%ebx,%eax,1),%edx
  74:	88 14 01             	mov    %dl,(%ecx,%eax,1)
  77:	83 c0 01             	add    $0x1,%eax
  7a:	84 d2                	test   %dl,%dl
  7c:	75 f2                	jne    70 <strcpy+0x10>
    ;
  return os;
}
  7e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  81:	89 c8                	mov    %ecx,%eax
  83:	c9                   	leave  
  84:	c3                   	ret    
  85:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  8c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000090 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  90:	55                   	push   %ebp
  91:	89 e5                	mov    %esp,%ebp
  93:	53                   	push   %ebx
  94:	8b 55 08             	mov    0x8(%ebp),%edx
  97:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  while(*p && *p == *q)
  9a:	0f b6 02             	movzbl (%edx),%eax
  9d:	84 c0                	test   %al,%al
  9f:	75 17                	jne    b8 <strcmp+0x28>
  a1:	eb 3a                	jmp    dd <strcmp+0x4d>
  a3:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  a7:	90                   	nop
  a8:	0f b6 42 01          	movzbl 0x1(%edx),%eax
    p++, q++;
  ac:	83 c2 01             	add    $0x1,%edx
  af:	8d 59 01             	lea    0x1(%ecx),%ebx
  while(*p && *p == *q)
  b2:	84 c0                	test   %al,%al
  b4:	74 1a                	je     d0 <strcmp+0x40>
    p++, q++;
  b6:	89 d9                	mov    %ebx,%ecx
  while(*p && *p == *q)
  b8:	0f b6 19             	movzbl (%ecx),%ebx
  bb:	38 c3                	cmp    %al,%bl
  bd:	74 e9                	je     a8 <strcmp+0x18>
  return (uchar)*p - (uchar)*q;
  bf:	29 d8                	sub    %ebx,%eax
}
  c1:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  c4:	c9                   	leave  
  c5:	c3                   	ret    
  c6:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  cd:	8d 76 00             	lea    0x0(%esi),%esi
  return (uchar)*p - (uchar)*q;
  d0:	0f b6 59 01          	movzbl 0x1(%ecx),%ebx
  d4:	31 c0                	xor    %eax,%eax
  d6:	29 d8                	sub    %ebx,%eax
}
  d8:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  db:	c9                   	leave  
  dc:	c3                   	ret    
  return (uchar)*p - (uchar)*q;
  dd:	0f b6 19             	movzbl (%ecx),%ebx
  e0:	31 c0                	xor    %eax,%eax
  e2:	eb db                	jmp    bf <strcmp+0x2f>
  e4:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  eb:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  ef:	90                   	nop

000000f0 <strlen>:

uint
strlen(const char *s)
{
  f0:	55                   	push   %ebp
  f1:	89 e5                	mov    %esp,%ebp
  f3:	8b 55 08             	mov    0x8(%ebp),%edx
  int n;

  for(n = 0; s[n]; n++)
  f6:	80 3a 00             	cmpb   $0x0,(%edx)
  f9:	74 15                	je     110 <strlen+0x20>
  fb:	31 c0                	xor    %eax,%eax
  fd:	8d 76 00             	lea    0x0(%esi),%esi
 100:	83 c0 01             	add    $0x1,%eax
 103:	80 3c 02 00          	cmpb   $0x0,(%edx,%eax,1)
 107:	89 c1                	mov    %eax,%ecx
 109:	75 f5                	jne    100 <strlen+0x10>
    ;
  return n;
}
 10b:	89 c8                	mov    %ecx,%eax
 10d:	5d                   	pop    %ebp
 10e:	c3                   	ret    
 10f:	90                   	nop
  for(n = 0; s[n]; n++)
 110:	31 c9                	xor    %ecx,%ecx
}
 112:	5d                   	pop    %ebp
 113:	89 c8                	mov    %ecx,%eax
 115:	c3                   	ret    
 116:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 11d:	8d 76 00             	lea    0x0(%esi),%esi

00000120 <memset>:

void*
memset(void *dst, int c, uint n)
{
 120:	55                   	push   %ebp
 121:	89 e5                	mov    %esp,%ebp
 123:	57                   	push   %edi
 124:	8b 55 08             	mov    0x8(%ebp),%edx
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
 127:	8b 4d 10             	mov    0x10(%ebp),%ecx
 12a:	8b 45 0c             	mov    0xc(%ebp),%eax
 12d:	89 d7                	mov    %edx,%edi
 12f:	fc                   	cld    
 130:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
 132:	8b 7d fc             	mov    -0x4(%ebp),%edi
 135:	89 d0                	mov    %edx,%eax
 137:	c9                   	leave  
 138:	c3                   	ret    
 139:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

00000140 <strchr>:

char*
strchr(const char *s, char c)
{
 140:	55                   	push   %ebp
 141:	89 e5                	mov    %esp,%ebp
 143:	8b 45 08             	mov    0x8(%ebp),%eax
 146:	0f b6 4d 0c          	movzbl 0xc(%ebp),%ecx
  for(; *s; s++)
 14a:	0f b6 10             	movzbl (%eax),%edx
 14d:	84 d2                	test   %dl,%dl
 14f:	75 12                	jne    163 <strchr+0x23>
 151:	eb 1d                	jmp    170 <strchr+0x30>
 153:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
 157:	90                   	nop
 158:	0f b6 50 01          	movzbl 0x1(%eax),%edx
 15c:	83 c0 01             	add    $0x1,%eax
 15f:	84 d2                	test   %dl,%dl
 161:	74 0d                	je     170 <strchr+0x30>
    if(*s == c)
 163:	38 d1                	cmp    %dl,%cl
 165:	75 f1                	jne    158 <strchr+0x18>
      return (char*)s;
  return 0;
}
 167:	5d                   	pop    %ebp
 168:	c3                   	ret    
 169:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  return 0;
 170:	31 c0                	xor    %eax,%eax
}
 172:	5d                   	pop    %ebp
 173:	c3                   	ret    
 174:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 17b:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
 17f:	90                   	nop

00000180 <gets>:

char*
gets(char *buf, int max)
{
 180:	55                   	push   %ebp
 181:	89 e5                	mov    %esp,%ebp
 183:	57                   	push   %edi
 184:	56                   	push   %esi
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
    cc = read(0, &c, 1);
 185:	8d 7d e7             	lea    -0x19(%ebp),%edi
{
 188:	53                   	push   %ebx
  for(i=0; i+1 < max; ){
 189:	31 db                	xor    %ebx,%ebx
{
 18b:	83 ec 1c             	sub    $0x1c,%esp
  for(i=0; i+1 < max; ){
 18e:	eb 27                	jmp    1b7 <gets+0x37>
    cc = read(0, &c, 1);
 190:	83 ec 04             	sub    $0x4,%esp
 193:	6a 01                	push   $0x1
 195:	57                   	push   %edi
 196:	6a 00                	push   $0x0
 198:	e8 2e 01 00 00       	call   2cb <read>
    if(cc < 1)
 19d:	83 c4 10             	add    $0x10,%esp
 1a0:	85 c0                	test   %eax,%eax
 1a2:	7e 1d                	jle    1c1 <gets+0x41>
      break;
    buf[i++] = c;
 1a4:	0f b6 45 e7          	movzbl -0x19(%ebp),%eax
 1a8:	8b 55 08             	mov    0x8(%ebp),%edx
 1ab:	88 44 1a ff          	mov    %al,-0x1(%edx,%ebx,1)
    if(c == '\n' || c == '\r')
 1af:	3c 0a                	cmp    $0xa,%al
 1b1:	74 1d                	je     1d0 <gets+0x50>
 1b3:	3c 0d                	cmp    $0xd,%al
 1b5:	74 19                	je     1d0 <gets+0x50>
  for(i=0; i+1 < max; ){
 1b7:	89 de                	mov    %ebx,%esi
 1b9:	83 c3 01             	add    $0x1,%ebx
 1bc:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 1bf:	7c cf                	jl     190 <gets+0x10>
      break;
  }
  buf[i] = '\0';
 1c1:	8b 45 08             	mov    0x8(%ebp),%eax
 1c4:	c6 04 30 00          	movb   $0x0,(%eax,%esi,1)
  return buf;
}
 1c8:	8d 65 f4             	lea    -0xc(%ebp),%esp
 1cb:	5b                   	pop    %ebx
 1cc:	5e                   	pop    %esi
 1cd:	5f                   	pop    %edi
 1ce:	5d                   	pop    %ebp
 1cf:	c3                   	ret    
  buf[i] = '\0';
 1d0:	8b 45 08             	mov    0x8(%ebp),%eax
 1d3:	89 de                	mov    %ebx,%esi
 1d5:	c6 04 30 00          	movb   $0x0,(%eax,%esi,1)
}
 1d9:	8d 65 f4             	lea    -0xc(%ebp),%esp
 1dc:	5b                   	pop    %ebx
 1dd:	5e                   	pop    %esi
 1de:	5f                   	pop    %edi
 1df:	5d                   	pop    %ebp
 1e0:	c3                   	ret    
 1e1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 1e8:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 1ef:	90                   	nop

000001f0 <stat>:

int
stat(const char *n, struct stat *st)
{
 1f0:	55                   	push   %ebp
 1f1:	89 e5                	mov    %esp,%ebp
 1f3:	56                   	push   %esi
 1f4:	53                   	push   %ebx
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 1f5:	83 ec 08             	sub    $0x8,%esp
 1f8:	6a 00                	push   $0x0
 1fa:	ff 75 08             	push   0x8(%ebp)
 1fd:	e8 f1 00 00 00       	call   2f3 <open>
  if(fd < 0)
 202:	83 c4 10             	add    $0x10,%esp
 205:	85 c0                	test   %eax,%eax
 207:	78 27                	js     230 <stat+0x40>
    return -1;
  r = fstat(fd, st);
 209:	83 ec 08             	sub    $0x8,%esp
 20c:	ff 75 0c             	push   0xc(%ebp)
 20f:	89 c3                	mov    %eax,%ebx
 211:	50                   	push   %eax
 212:	e8 f4 00 00 00       	call   30b <fstat>
  close(fd);
 217:	89 1c 24             	mov    %ebx,(%esp)
  r = fstat(fd, st);
 21a:	89 c6                	mov    %eax,%esi
  close(fd);
 21c:	e8 ba 00 00 00       	call   2db <close>
  return r;
 221:	83 c4 10             	add    $0x10,%esp
}
 224:	8d 65 f8             	lea    -0x8(%ebp),%esp
 227:	89 f0                	mov    %esi,%eax
 229:	5b                   	pop    %ebx
 22a:	5e                   	pop    %esi
 22b:	5d                   	pop    %ebp
 22c:	c3                   	ret    
 22d:	8d 76 00             	lea    0x0(%esi),%esi
    return -1;
 230:	be ff ff ff ff       	mov    $0xffffffff,%esi
 235:	eb ed                	jmp    224 <stat+0x34>
 237:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 23e:	66 90                	xchg   %ax,%ax

00000240 <atoi>:

int
atoi(const char *s)
{
 240:	55                   	push   %ebp
 241:	89 e5                	mov    %esp,%ebp
 243:	53                   	push   %ebx
 244:	8b 55 08             	mov    0x8(%ebp),%edx
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 247:	0f be 02             	movsbl (%edx),%eax
 24a:	8d 48 d0             	lea    -0x30(%eax),%ecx
 24d:	80 f9 09             	cmp    $0x9,%cl
  n = 0;
 250:	b9 00 00 00 00       	mov    $0x0,%ecx
  while('0' <= *s && *s <= '9')
 255:	77 1e                	ja     275 <atoi+0x35>
 257:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 25e:	66 90                	xchg   %ax,%ax
    n = n*10 + *s++ - '0';
 260:	83 c2 01             	add    $0x1,%edx
 263:	8d 0c 89             	lea    (%ecx,%ecx,4),%ecx
 266:	8d 4c 48 d0          	lea    -0x30(%eax,%ecx,2),%ecx
  while('0' <= *s && *s <= '9')
 26a:	0f be 02             	movsbl (%edx),%eax
 26d:	8d 58 d0             	lea    -0x30(%eax),%ebx
 270:	80 fb 09             	cmp    $0x9,%bl
 273:	76 eb                	jbe    260 <atoi+0x20>
  return n;
}
 275:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 278:	89 c8                	mov    %ecx,%eax
 27a:	c9                   	leave  
 27b:	c3                   	ret    
 27c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000280 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 280:	55                   	push   %ebp
 281:	89 e5                	mov    %esp,%ebp
 283:	57                   	push   %edi
 284:	8b 45 10             	mov    0x10(%ebp),%eax
 287:	8b 55 08             	mov    0x8(%ebp),%edx
 28a:	56                   	push   %esi
 28b:	8b 75 0c             	mov    0xc(%ebp),%esi
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  while(n-- > 0)
 28e:	85 c0                	test   %eax,%eax
 290:	7e 13                	jle    2a5 <memmove+0x25>
 292:	01 d0                	add    %edx,%eax
  dst = vdst;
 294:	89 d7                	mov    %edx,%edi
 296:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 29d:	8d 76 00             	lea    0x0(%esi),%esi
    *dst++ = *src++;
 2a0:	a4                   	movsb  %ds:(%esi),%es:(%edi)
  while(n-- > 0)
 2a1:	39 f8                	cmp    %edi,%eax
 2a3:	75 fb                	jne    2a0 <memmove+0x20>
  return vdst;
}
 2a5:	5e                   	pop    %esi
 2a6:	89 d0                	mov    %edx,%eax
 2a8:	5f                   	pop    %edi
 2a9:	5d                   	pop    %ebp
 2aa:	c3                   	ret    

000002ab <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 2ab:	b8 01 00 00 00       	mov    $0x1,%eax
 2b0:	cd 40                	int    $0x40
 2b2:	c3                   	ret    

000002b3 <exit>:
SYSCALL(exit)
 2b3:	b8 02 00 00 00       	mov    $0x2,%eax
 2b8:	cd 40                	int    $0x40
 2ba:	c3                   	ret    

000002bb <wait>:
SYSCALL(wait)
 2bb:	b8 03 00 00 00       	mov    $0x3,%eax
 2c0:	cd 40                	int    $0x40
 2c2:	c3                   	ret    

000002c3 <pipe>:
SYSCALL(pipe)
 2c3:	b8 04 00 00 00       	mov    $0x4,%eax
 2c8:	cd 40                	int    $0x40
 2ca:	c3                   	ret    

000002cb <read>:
SYSCALL(read)
 2cb:	b8 05 00 00 00       	mov    $0x5,%eax
 2d0:	cd 40                	int    $0x40
 2d2:	c3                   	ret    

000002d3 <write>:
SYSCALL(write)
 2d3:	b8 10 00 00 00       	mov    $0x10,%eax
 2d8:	cd 40                	int    $0x40
 2da:	c3                   	ret    

000002db <close>:
SYSCALL(close)
 2db:	b8 15 00 00 00       	mov    $0x15,%eax
 2e0:	cd 40                	int    $0x40
 2e2:	c3                   	ret    

000002e3 <kill>:
SYSCALL(kill)
 2e3:	b8 06 00 00 00       	mov    $0x6,%eax
 2e8:	cd 40                	int    $0x40
 2ea:	c3                   	ret    

000002eb <exec>:
SYSCALL(exec)
 2eb:	b8 07 00 00 00       	mov    $0x7,%eax
 2f0:	cd 40                	int    $0x40
 2f2:	c3                   	ret    

000002f3 <open>:
SYSCALL(open)
 2f3:	b8 0f 00 00 00       	mov    $0xf,%eax
 2f8:	cd 40                	int    $0x40
 2fa:	c3                   	ret    

000002fb <mknod>:
SYSCALL(mknod)
 2fb:	b8 11 00 00 00       	mov    $0x11,%eax
 300:	cd 40                	int    $0x40
 302:	c3                   	ret    

00000303 <unlink>:
SYSCALL(unlink)
 303:	b8 12 00 00 00       	mov    $0x12,%eax
 308:	cd 40                	int    $0x40
 30a:	c3                   	ret    

0000030b <fstat>:
SYSCALL(fstat)
 30b:	b8 08 00 00 00       	mov    $0x8,%eax
 310:	cd 40                	int    $0x40
 312:	c3                   	ret    

00000313 <link>:
SYSCALL(link)
 313:	b8 13 00 00 00       	mov    $0x13,%eax
 318:	cd 40                	int    $0x40
 31a:	c3                   	ret    

0000031b <mkdir>:
SYSCALL(mkdir)
 31b:	b8 14 00 00 00       	mov    $0x14,%eax
 320:	cd 40                	int    $0x40
 322:	c3                   	ret    

00000323 <chdir>:
SYSCALL(chdir)
 323:	b8 09 00 00 00       	mov    $0x9,%eax
 328:	cd 40                	int    $0x40
 32a:	c3                   	ret    

0000032b <dup>:
SYSCALL(dup)
 32b:	b8 0a 00 00 00       	mov    $0xa,%eax
 330:	cd 40                	int    $0x40
 332:	c3                   	ret    

00000333 <getpid>:
SYSCALL(getpid)
 333:	b8 0b 00 00 00       	mov    $0xb,%eax
 338:	cd 40                	int    $0x40
 33a:	c3                   	ret    

0000033b <sbrk>:
SYSCALL(sbrk)
 33b:	b8 0c 00 00 00       	mov    $0xc,%eax
 340:	cd 40                	int    $0x40
 342:	c3                   	ret    

00000343 <sleep>:
SYSCALL(sleep)
 343:	b8 0d 00 00 00       	mov    $0xd,%eax
 348:	cd 40                	int    $0x40
 34a:	c3                   	ret    

0000034b <uptime>:
SYSCALL(uptime)
 34b:	b8 0e 00 00 00       	mov    $0xe,%eax
 350:	cd 40                	int    $0x40
 352:	c3                   	ret    
 353:	66 90                	xchg   %ax,%ax
 355:	66 90                	xchg   %ax,%ax
 357:	66 90                	xchg   %ax,%ax
 359:	66 90                	xchg   %ax,%ax
 35b:	66 90                	xchg   %ax,%ax
 35d:	66 90                	xchg   %ax,%ax
 35f:	90                   	nop

00000360 <printint>:
  write(fd, &c, 1);
}

static void
printint(int fd, int xx, int base, int sgn)
{
 360:	55                   	push   %ebp
 361:	89 e5                	mov    %esp,%ebp
 363:	57                   	push   %edi
 364:	56                   	push   %esi
 365:	53                   	push   %ebx
 366:	83 ec 3c             	sub    $0x3c,%esp
 369:	89 4d c4             	mov    %ecx,-0x3c(%ebp)
  uint x;

  neg = 0;
  if(sgn && xx < 0){
    neg = 1;
    x = -xx;
 36c:	89 d1                	mov    %edx,%ecx
{
 36e:	89 45 b8             	mov    %eax,-0x48(%ebp)
  if(sgn && xx < 0){
 371:	85 d2                	test   %edx,%edx
 373:	0f 89 7f 00 00 00    	jns    3f8 <printint+0x98>
 379:	f6 45 08 01          	testb  $0x1,0x8(%ebp)
 37d:	74 79                	je     3f8 <printint+0x98>
    neg = 1;
 37f:	c7 45 bc 01 00 00 00 	movl   $0x1,-0x44(%ebp)
    x = -xx;
 386:	f7 d9                	neg    %ecx
  } else {
    x = xx;
  }

  i = 0;
 388:	31 db                	xor    %ebx,%ebx
 38a:	8d 75 d7             	lea    -0x29(%ebp),%esi
 38d:	8d 76 00             	lea    0x0(%esi),%esi
  do{
    buf[i++] = digits[x % base];
 390:	89 c8                	mov    %ecx,%eax
 392:	31 d2                	xor    %edx,%edx
 394:	89 cf                	mov    %ecx,%edi
 396:	f7 75 c4             	divl   -0x3c(%ebp)
 399:	0f b6 92 38 0a 00 00 	movzbl 0xa38(%edx),%edx
 3a0:	89 45 c0             	mov    %eax,-0x40(%ebp)
 3a3:	89 d8                	mov    %ebx,%eax
 3a5:	8d 5b 01             	lea    0x1(%ebx),%ebx
  }while((x /= base) != 0);
 3a8:	8b 4d c0             	mov    -0x40(%ebp),%ecx
    buf[i++] = digits[x % base];
 3ab:	88 14 1e             	mov    %dl,(%esi,%ebx,1)
  }while((x /= base) != 0);
 3ae:	39 7d c4             	cmp    %edi,-0x3c(%ebp)
 3b1:	76 dd                	jbe    390 <printint+0x30>
  if(neg)
 3b3:	8b 4d bc             	mov    -0x44(%ebp),%ecx
 3b6:	85 c9                	test   %ecx,%ecx
 3b8:	74 0c                	je     3c6 <printint+0x66>
    buf[i++] = '-';
 3ba:	c6 44 1d d8 2d       	movb   $0x2d,-0x28(%ebp,%ebx,1)
    buf[i++] = digits[x % base];
 3bf:	89 d8                	mov    %ebx,%eax
    buf[i++] = '-';
 3c1:	ba 2d 00 00 00       	mov    $0x2d,%edx

  while(--i >= 0)
 3c6:	8b 7d b8             	mov    -0x48(%ebp),%edi
 3c9:	8d 5c 05 d7          	lea    -0x29(%ebp,%eax,1),%ebx
 3cd:	eb 07                	jmp    3d6 <printint+0x76>
 3cf:	90                   	nop
    putc(fd, buf[i]);
 3d0:	0f b6 13             	movzbl (%ebx),%edx
 3d3:	83 eb 01             	sub    $0x1,%ebx
  write(fd, &c, 1);
 3d6:	83 ec 04             	sub    $0x4,%esp
 3d9:	88 55 d7             	mov    %dl,-0x29(%ebp)
 3dc:	6a 01                	push   $0x1
 3de:	56                   	push   %esi
 3df:	57                   	push   %edi
 3e0:	e8 ee fe ff ff       	call   2d3 <write>
  while(--i >= 0)
 3e5:	83 c4 10             	add    $0x10,%esp
 3e8:	39 de                	cmp    %ebx,%esi
 3ea:	75 e4                	jne    3d0 <printint+0x70>
}
 3ec:	8d 65 f4             	lea    -0xc(%ebp),%esp
 3ef:	5b                   	pop    %ebx
 3f0:	5e                   	pop    %esi
 3f1:	5f                   	pop    %edi
 3f2:	5d                   	pop    %ebp
 3f3:	c3                   	ret    
 3f4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  neg = 0;
 3f8:	c7 45 bc 00 00 00 00 	movl   $0x0,-0x44(%ebp)
 3ff:	eb 87                	jmp    388 <printint+0x28>
 401:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 408:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 40f:	90                   	nop

00000410 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 410:	55                   	push   %ebp
 411:	89 e5                	mov    %esp,%ebp
 413:	57                   	push   %edi
 414:	56                   	push   %esi
 415:	53                   	push   %ebx
 416:	83 ec 2c             	sub    $0x2c,%esp
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
  for(i = 0; fmt[i]; i++){
 419:	8b 5d 0c             	mov    0xc(%ebp),%ebx
{
 41c:	8b 75 08             	mov    0x8(%ebp),%esi
  for(i = 0; fmt[i]; i++){
 41f:	0f b6 13             	movzbl (%ebx),%edx
 422:	84 d2                	test   %dl,%dl
 424:	74 6a                	je     490 <printf+0x80>
  ap = (uint*)(void*)&fmt + 1;
 426:	8d 45 10             	lea    0x10(%ebp),%eax
 429:	83 c3 01             	add    $0x1,%ebx
  write(fd, &c, 1);
 42c:	8d 7d e7             	lea    -0x19(%ebp),%edi
  state = 0;
 42f:	31 c9                	xor    %ecx,%ecx
  ap = (uint*)(void*)&fmt + 1;
 431:	89 45 d0             	mov    %eax,-0x30(%ebp)
 434:	eb 36                	jmp    46c <printf+0x5c>
 436:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 43d:	8d 76 00             	lea    0x0(%esi),%esi
 440:	89 4d d4             	mov    %ecx,-0x2c(%ebp)
    c = fmt[i] & 0xff;
    if(state == 0){
      if(c == '%'){
        state = '%';
 443:	b9 25 00 00 00       	mov    $0x25,%ecx
      if(c == '%'){
 448:	83 f8 25             	cmp    $0x25,%eax
 44b:	74 15                	je     462 <printf+0x52>
  write(fd, &c, 1);
 44d:	83 ec 04             	sub    $0x4,%esp
 450:	88 55 e7             	mov    %dl,-0x19(%ebp)
 453:	6a 01                	push   $0x1
 455:	57                   	push   %edi
 456:	56                   	push   %esi
 457:	e8 77 fe ff ff       	call   2d3 <write>
 45c:	8b 4d d4             	mov    -0x2c(%ebp),%ecx
      } else {
        putc(fd, c);
 45f:	83 c4 10             	add    $0x10,%esp
  for(i = 0; fmt[i]; i++){
 462:	0f b6 13             	movzbl (%ebx),%edx
 465:	83 c3 01             	add    $0x1,%ebx
 468:	84 d2                	test   %dl,%dl
 46a:	74 24                	je     490 <printf+0x80>
    c = fmt[i] & 0xff;
 46c:	0f b6 c2             	movzbl %dl,%eax
    if(state == 0){
 46f:	85 c9                	test   %ecx,%ecx
 471:	74 cd                	je     440 <printf+0x30>
      }
    } else if(state == '%'){
 473:	83 f9 25             	cmp    $0x25,%ecx
 476:	75 ea                	jne    462 <printf+0x52>
      if(c == 'd'){
 478:	83 f8 25             	cmp    $0x25,%eax
 47b:	0f 84 07 01 00 00    	je     588 <printf+0x178>
 481:	83 e8 63             	sub    $0x63,%eax
 484:	83 f8 15             	cmp    $0x15,%eax
 487:	77 17                	ja     4a0 <printf+0x90>
 489:	ff 24 85 e0 09 00 00 	jmp    *0x9e0(,%eax,4)
        putc(fd, c);
      }
      state = 0;
    }
  }
}
 490:	8d 65 f4             	lea    -0xc(%ebp),%esp
 493:	5b                   	pop    %ebx
 494:	5e                   	pop    %esi
 495:	5f                   	pop    %edi
 496:	5d                   	pop    %ebp
 497:	c3                   	ret    
 498:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 49f:	90                   	nop
  write(fd, &c, 1);
 4a0:	83 ec 04             	sub    $0x4,%esp
 4a3:	88 55 d4             	mov    %dl,-0x2c(%ebp)
 4a6:	6a 01                	push   $0x1
 4a8:	57                   	push   %edi
 4a9:	56                   	push   %esi
 4aa:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
 4ae:	e8 20 fe ff ff       	call   2d3 <write>
        putc(fd, c);
 4b3:	0f b6 55 d4          	movzbl -0x2c(%ebp),%edx
  write(fd, &c, 1);
 4b7:	83 c4 0c             	add    $0xc,%esp
 4ba:	88 55 e7             	mov    %dl,-0x19(%ebp)
 4bd:	6a 01                	push   $0x1
 4bf:	57                   	push   %edi
 4c0:	56                   	push   %esi
 4c1:	e8 0d fe ff ff       	call   2d3 <write>
        putc(fd, c);
 4c6:	83 c4 10             	add    $0x10,%esp
      state = 0;
 4c9:	31 c9                	xor    %ecx,%ecx
 4cb:	eb 95                	jmp    462 <printf+0x52>
 4cd:	8d 76 00             	lea    0x0(%esi),%esi
        printint(fd, *ap, 16, 0);
 4d0:	83 ec 0c             	sub    $0xc,%esp
 4d3:	b9 10 00 00 00       	mov    $0x10,%ecx
 4d8:	6a 00                	push   $0x0
 4da:	8b 45 d0             	mov    -0x30(%ebp),%eax
 4dd:	8b 10                	mov    (%eax),%edx
 4df:	89 f0                	mov    %esi,%eax
 4e1:	e8 7a fe ff ff       	call   360 <printint>
        ap++;
 4e6:	83 45 d0 04          	addl   $0x4,-0x30(%ebp)
 4ea:	83 c4 10             	add    $0x10,%esp
      state = 0;
 4ed:	31 c9                	xor    %ecx,%ecx
 4ef:	e9 6e ff ff ff       	jmp    462 <printf+0x52>
 4f4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
        s = (char*)*ap;
 4f8:	8b 45 d0             	mov    -0x30(%ebp),%eax
 4fb:	8b 10                	mov    (%eax),%edx
        ap++;
 4fd:	83 c0 04             	add    $0x4,%eax
 500:	89 45 d0             	mov    %eax,-0x30(%ebp)
        if(s == 0)
 503:	85 d2                	test   %edx,%edx
 505:	0f 84 8d 00 00 00    	je     598 <printf+0x188>
        while(*s != 0){
 50b:	0f b6 02             	movzbl (%edx),%eax
      state = 0;
 50e:	31 c9                	xor    %ecx,%ecx
        while(*s != 0){
 510:	84 c0                	test   %al,%al
 512:	0f 84 4a ff ff ff    	je     462 <printf+0x52>
 518:	89 5d d4             	mov    %ebx,-0x2c(%ebp)
 51b:	89 d3                	mov    %edx,%ebx
 51d:	8d 76 00             	lea    0x0(%esi),%esi
  write(fd, &c, 1);
 520:	83 ec 04             	sub    $0x4,%esp
          s++;
 523:	83 c3 01             	add    $0x1,%ebx
 526:	88 45 e7             	mov    %al,-0x19(%ebp)
  write(fd, &c, 1);
 529:	6a 01                	push   $0x1
 52b:	57                   	push   %edi
 52c:	56                   	push   %esi
 52d:	e8 a1 fd ff ff       	call   2d3 <write>
        while(*s != 0){
 532:	0f b6 03             	movzbl (%ebx),%eax
 535:	83 c4 10             	add    $0x10,%esp
 538:	84 c0                	test   %al,%al
 53a:	75 e4                	jne    520 <printf+0x110>
      state = 0;
 53c:	8b 5d d4             	mov    -0x2c(%ebp),%ebx
 53f:	31 c9                	xor    %ecx,%ecx
 541:	e9 1c ff ff ff       	jmp    462 <printf+0x52>
 546:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 54d:	8d 76 00             	lea    0x0(%esi),%esi
        printint(fd, *ap, 10, 1);
 550:	83 ec 0c             	sub    $0xc,%esp
 553:	b9 0a 00 00 00       	mov    $0xa,%ecx
 558:	6a 01                	push   $0x1
 55a:	e9 7b ff ff ff       	jmp    4da <printf+0xca>
 55f:	90                   	nop
        putc(fd, *ap);
 560:	8b 45 d0             	mov    -0x30(%ebp),%eax
  write(fd, &c, 1);
 563:	83 ec 04             	sub    $0x4,%esp
        putc(fd, *ap);
 566:	8b 00                	mov    (%eax),%eax
  write(fd, &c, 1);
 568:	6a 01                	push   $0x1
 56a:	57                   	push   %edi
 56b:	56                   	push   %esi
        putc(fd, *ap);
 56c:	88 45 e7             	mov    %al,-0x19(%ebp)
  write(fd, &c, 1);
 56f:	e8 5f fd ff ff       	call   2d3 <write>
        ap++;
 574:	83 45 d0 04          	addl   $0x4,-0x30(%ebp)
 578:	83 c4 10             	add    $0x10,%esp
      state = 0;
 57b:	31 c9                	xor    %ecx,%ecx
 57d:	e9 e0 fe ff ff       	jmp    462 <printf+0x52>
 582:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
        putc(fd, c);
 588:	88 55 e7             	mov    %dl,-0x19(%ebp)
  write(fd, &c, 1);
 58b:	83 ec 04             	sub    $0x4,%esp
 58e:	e9 2a ff ff ff       	jmp    4bd <printf+0xad>
 593:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
 597:	90                   	nop
          s = "(null)";
 598:	ba d8 09 00 00       	mov    $0x9d8,%edx
        while(*s != 0){
 59d:	89 5d d4             	mov    %ebx,-0x2c(%ebp)
 5a0:	b8 28 00 00 00       	mov    $0x28,%eax
 5a5:	89 d3                	mov    %edx,%ebx
 5a7:	e9 74 ff ff ff       	jmp    520 <printf+0x110>
 5ac:	66 90                	xchg   %ax,%ax
 5ae:	66 90                	xchg   %ax,%ax

000005b0 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 5b0:	55                   	push   %ebp
  Header *bp, *p;

  bp = (Header*)ap - 1;
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 5b1:	a1 40 0e 00 00       	mov    0xe40,%eax
{
 5b6:	89 e5                	mov    %esp,%ebp
 5b8:	57                   	push   %edi
 5b9:	56                   	push   %esi
 5ba:	53                   	push   %ebx
 5bb:	8b 5d 08             	mov    0x8(%ebp),%ebx
  bp = (Header*)ap - 1;
 5be:	8d 4b f8             	lea    -0x8(%ebx),%ecx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 5c1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 5c8:	89 c2                	mov    %eax,%edx
 5ca:	8b 00                	mov    (%eax),%eax
 5cc:	39 ca                	cmp    %ecx,%edx
 5ce:	73 30                	jae    600 <free+0x50>
 5d0:	39 c1                	cmp    %eax,%ecx
 5d2:	72 04                	jb     5d8 <free+0x28>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 5d4:	39 c2                	cmp    %eax,%edx
 5d6:	72 f0                	jb     5c8 <free+0x18>
      break;
  if(bp + bp->s.size == p->s.ptr){
 5d8:	8b 73 fc             	mov    -0x4(%ebx),%esi
 5db:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 5de:	39 f8                	cmp    %edi,%eax
 5e0:	74 30                	je     612 <free+0x62>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 5e2:	89 43 f8             	mov    %eax,-0x8(%ebx)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 5e5:	8b 42 04             	mov    0x4(%edx),%eax
 5e8:	8d 34 c2             	lea    (%edx,%eax,8),%esi
 5eb:	39 f1                	cmp    %esi,%ecx
 5ed:	74 3a                	je     629 <free+0x79>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 5ef:	89 0a                	mov    %ecx,(%edx)
  } else
    p->s.ptr = bp;
  freep = p;
}
 5f1:	5b                   	pop    %ebx
  freep = p;
 5f2:	89 15 40 0e 00 00    	mov    %edx,0xe40
}
 5f8:	5e                   	pop    %esi
 5f9:	5f                   	pop    %edi
 5fa:	5d                   	pop    %ebp
 5fb:	c3                   	ret    
 5fc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 600:	39 c2                	cmp    %eax,%edx
 602:	72 c4                	jb     5c8 <free+0x18>
 604:	39 c1                	cmp    %eax,%ecx
 606:	73 c0                	jae    5c8 <free+0x18>
  if(bp + bp->s.size == p->s.ptr){
 608:	8b 73 fc             	mov    -0x4(%ebx),%esi
 60b:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 60e:	39 f8                	cmp    %edi,%eax
 610:	75 d0                	jne    5e2 <free+0x32>
    bp->s.size += p->s.ptr->s.size;
 612:	03 70 04             	add    0x4(%eax),%esi
 615:	89 73 fc             	mov    %esi,-0x4(%ebx)
    bp->s.ptr = p->s.ptr->s.ptr;
 618:	8b 02                	mov    (%edx),%eax
 61a:	8b 00                	mov    (%eax),%eax
 61c:	89 43 f8             	mov    %eax,-0x8(%ebx)
  if(p + p->s.size == bp){
 61f:	8b 42 04             	mov    0x4(%edx),%eax
 622:	8d 34 c2             	lea    (%edx,%eax,8),%esi
 625:	39 f1                	cmp    %esi,%ecx
 627:	75 c6                	jne    5ef <free+0x3f>
    p->s.size += bp->s.size;
 629:	03 43 fc             	add    -0x4(%ebx),%eax
  freep = p;
 62c:	89 15 40 0e 00 00    	mov    %edx,0xe40
    p->s.size += bp->s.size;
 632:	89 42 04             	mov    %eax,0x4(%edx)
    p->s.ptr = bp->s.ptr;
 635:	8b 4b f8             	mov    -0x8(%ebx),%ecx
 638:	89 0a                	mov    %ecx,(%edx)
}
 63a:	5b                   	pop    %ebx
 63b:	5e                   	pop    %esi
 63c:	5f                   	pop    %edi
 63d:	5d                   	pop    %ebp
 63e:	c3                   	ret    
 63f:	90                   	nop

00000640 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 640:	55                   	push   %ebp
 641:	89 e5                	mov    %esp,%ebp
 643:	57                   	push   %edi
 644:	56                   	push   %esi
 645:	53                   	push   %ebx
 646:	83 ec 1c             	sub    $0x1c,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 649:	8b 45 08             	mov    0x8(%ebp),%eax
  if((prevp = freep) == 0){
 64c:	8b 3d 40 0e 00 00    	mov    0xe40,%edi
  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 652:	8d 70 07             	lea    0x7(%eax),%esi
 655:	c1 ee 03             	shr    $0x3,%esi
 658:	83 c6 01             	add    $0x1,%esi
  if((prevp = freep) == 0){
 65b:	85 ff                	test   %edi,%edi
 65d:	0f 84 9d 00 00 00    	je     700 <malloc+0xc0>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 663:	8b 17                	mov    (%edi),%edx
    if(p->s.size >= nunits){
 665:	8b 4a 04             	mov    0x4(%edx),%ecx
 668:	39 f1                	cmp    %esi,%ecx
 66a:	73 6a                	jae    6d6 <malloc+0x96>
 66c:	bb 00 10 00 00       	mov    $0x1000,%ebx
 671:	39 de                	cmp    %ebx,%esi
 673:	0f 43 de             	cmovae %esi,%ebx
  p = sbrk(nu * sizeof(Header));
 676:	8d 04 dd 00 00 00 00 	lea    0x0(,%ebx,8),%eax
 67d:	89 45 e4             	mov    %eax,-0x1c(%ebp)
 680:	eb 17                	jmp    699 <malloc+0x59>
 682:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 688:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 68a:	8b 48 04             	mov    0x4(%eax),%ecx
 68d:	39 f1                	cmp    %esi,%ecx
 68f:	73 4f                	jae    6e0 <malloc+0xa0>
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 691:	8b 3d 40 0e 00 00    	mov    0xe40,%edi
 697:	89 c2                	mov    %eax,%edx
 699:	39 d7                	cmp    %edx,%edi
 69b:	75 eb                	jne    688 <malloc+0x48>
  p = sbrk(nu * sizeof(Header));
 69d:	83 ec 0c             	sub    $0xc,%esp
 6a0:	ff 75 e4             	push   -0x1c(%ebp)
 6a3:	e8 93 fc ff ff       	call   33b <sbrk>
  if(p == (char*)-1)
 6a8:	83 c4 10             	add    $0x10,%esp
 6ab:	83 f8 ff             	cmp    $0xffffffff,%eax
 6ae:	74 1c                	je     6cc <malloc+0x8c>
  hp->s.size = nu;
 6b0:	89 58 04             	mov    %ebx,0x4(%eax)
  free((void*)(hp + 1));
 6b3:	83 ec 0c             	sub    $0xc,%esp
 6b6:	83 c0 08             	add    $0x8,%eax
 6b9:	50                   	push   %eax
 6ba:	e8 f1 fe ff ff       	call   5b0 <free>
  return freep;
 6bf:	8b 15 40 0e 00 00    	mov    0xe40,%edx
      if((p = morecore(nunits)) == 0)
 6c5:	83 c4 10             	add    $0x10,%esp
 6c8:	85 d2                	test   %edx,%edx
 6ca:	75 bc                	jne    688 <malloc+0x48>
        return 0;
  }
}
 6cc:	8d 65 f4             	lea    -0xc(%ebp),%esp
        return 0;
 6cf:	31 c0                	xor    %eax,%eax
}
 6d1:	5b                   	pop    %ebx
 6d2:	5e                   	pop    %esi
 6d3:	5f                   	pop    %edi
 6d4:	5d                   	pop    %ebp
 6d5:	c3                   	ret    
    if(p->s.size >= nunits){
 6d6:	89 d0                	mov    %edx,%eax
 6d8:	89 fa                	mov    %edi,%edx
 6da:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      if(p->s.size == nunits)
 6e0:	39 ce                	cmp    %ecx,%esi
 6e2:	74 4c                	je     730 <malloc+0xf0>
        p->s.size -= nunits;
 6e4:	29 f1                	sub    %esi,%ecx
 6e6:	89 48 04             	mov    %ecx,0x4(%eax)
        p += p->s.size;
 6e9:	8d 04 c8             	lea    (%eax,%ecx,8),%eax
        p->s.size = nunits;
 6ec:	89 70 04             	mov    %esi,0x4(%eax)
      freep = prevp;
 6ef:	89 15 40 0e 00 00    	mov    %edx,0xe40
}
 6f5:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return (void*)(p + 1);
 6f8:	83 c0 08             	add    $0x8,%eax
}
 6fb:	5b                   	pop    %ebx
 6fc:	5e                   	pop    %esi
 6fd:	5f                   	pop    %edi
 6fe:	5d                   	pop    %ebp
 6ff:	c3                   	ret    
    base.s.ptr = freep = prevp = &base;
 700:	c7 05 40 0e 00 00 44 	movl   $0xe44,0xe40
 707:	0e 00 00 
    base.s.size = 0;
 70a:	bf 44 0e 00 00       	mov    $0xe44,%edi
    base.s.ptr = freep = prevp = &base;
 70f:	c7 05 44 0e 00 00 44 	movl   $0xe44,0xe44
 716:	0e 00 00 
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 719:	89 fa                	mov    %edi,%edx
    base.s.size = 0;
 71b:	c7 05 48 0e 00 00 00 	movl   $0x0,0xe48
 722:	00 00 00 
    if(p->s.size >= nunits){
 725:	e9 42 ff ff ff       	jmp    66c <malloc+0x2c>
 72a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
        prevp->s.ptr = p->s.ptr;
 730:	8b 08                	mov    (%eax),%ecx
 732:	89 0a                	mov    %ecx,(%edx)
 734:	eb b9                	jmp    6ef <malloc+0xaf>
 736:	66 90                	xchg   %ax,%ax
 738:	66 90                	xchg   %ax,%ax
 73a:	66 90                	xchg   %ax,%ax
 73c:	66 90                	xchg   %ax,%ax
 73e:	66 90                	xchg   %ax,%ax

00000740 <thread_init>:
  thread_yield();
}

void thread_init(void) {
  // Initialize the main thread
  current_thread = &threads[0];
 740:	c7 05 60 0e 00 00 80 	movl   $0xe80,0xe60
 747:	0e 00 00 
  current_thread->tid = 0;
 74a:	c7 05 80 0e 00 00 00 	movl   $0x0,0xe80
 751:	00 00 00 
  current_thread->state = RUNNING;
 754:	c7 05 84 0e 00 00 02 	movl   $0x2,0xe84
 75b:	00 00 00 
}
 75e:	c3                   	ret    
 75f:	90                   	nop

00000760 <thread_create>:

tid_t thread_create(void (*fn)(void*), void *arg) {
  struct thread *t = 0;
  
  // Find a FREE thread slot
  for (int i = 0; i < MAX_THREADS; i++) {
 760:	ba 84 0e 00 00       	mov    $0xe84,%edx
 765:	31 c0                	xor    %eax,%eax
 767:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 76e:	66 90                	xchg   %ax,%ax
    if (threads[i].state == FREE) {
 770:	8b 0a                	mov    (%edx),%ecx
 772:	85 c9                	test   %ecx,%ecx
 774:	74 1a                	je     790 <thread_create+0x30>
  for (int i = 0; i < MAX_THREADS; i++) {
 776:	83 c0 01             	add    $0x1,%eax
 779:	81 c2 14 10 00 00    	add    $0x1014,%edx
 77f:	83 f8 08             	cmp    $0x8,%eax
 782:	75 ec                	jne    770 <thread_create+0x10>
      t = &threads[i];
      break;
    }
  }
  
  if (!t) return -1; // No available threads
 784:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  // Initialize the context to 0, and set the instruction pointer to the stub
  memset(t->context, 0, sizeof(struct context));
  t->context->eip = (uint)thread_stub;
  
  return t->tid;
}
 789:	c3                   	ret    
 78a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
tid_t thread_create(void (*fn)(void*), void *arg) {
 790:	55                   	push   %ebp
  t->tid = next_tid++;
 791:	8b 15 20 0e 00 00    	mov    0xe20,%edx
 797:	8d 4a 01             	lea    0x1(%edx),%ecx
tid_t thread_create(void (*fn)(void*), void *arg) {
 79a:	89 e5                	mov    %esp,%ebp
 79c:	56                   	push   %esi
 79d:	53                   	push   %ebx
  t->tid = next_tid++;
 79e:	69 d8 14 10 00 00    	imul   $0x1014,%eax,%ebx
  t->fn = fn;
 7a4:	8b 45 08             	mov    0x8(%ebp),%eax
  t->tid = next_tid++;
 7a7:	89 0d 20 0e 00 00    	mov    %ecx,0xe20
  t->fn = fn;
 7ad:	89 83 8c 1e 00 00    	mov    %eax,0x1e8c(%ebx)
  t->arg = arg;
 7b3:	8b 45 0c             	mov    0xc(%ebp),%eax
  memset(t->context, 0, sizeof(struct context));
 7b6:	83 ec 04             	sub    $0x4,%esp
 7b9:	6a 14                	push   $0x14
  t->arg = arg;
 7bb:	89 83 90 1e 00 00    	mov    %eax,0x1e90(%ebx)
  sp -= sizeof(struct context);
 7c1:	8d 83 74 1e 00 00    	lea    0x1e74(%ebx),%eax
  memset(t->context, 0, sizeof(struct context));
 7c7:	6a 00                	push   $0x0
 7c9:	50                   	push   %eax
  t->tid = next_tid++;
 7ca:	89 93 80 0e 00 00    	mov    %edx,0xe80(%ebx)
  t->state = RUNNABLE;
 7d0:	c7 83 84 0e 00 00 01 	movl   $0x1,0xe84(%ebx)
 7d7:	00 00 00 
  t->context = (struct context*)sp;
 7da:	89 83 88 1e 00 00    	mov    %eax,0x1e88(%ebx)
  memset(t->context, 0, sizeof(struct context));
 7e0:	e8 3b f9 ff ff       	call   120 <memset>
  t->context->eip = (uint)thread_stub;
 7e5:	8b 83 88 1e 00 00    	mov    0x1e88(%ebx),%eax
  return t->tid;
 7eb:	83 c4 10             	add    $0x10,%esp
  t->context->eip = (uint)thread_stub;
 7ee:	c7 40 10 b0 08 00 00 	movl   $0x8b0,0x10(%eax)
  return t->tid;
 7f5:	8b 83 80 0e 00 00    	mov    0xe80(%ebx),%eax
}
 7fb:	8d 65 f8             	lea    -0x8(%ebp),%esp
 7fe:	5b                   	pop    %ebx
 7ff:	5e                   	pop    %esi
 800:	5d                   	pop    %ebp
 801:	c3                   	ret    
 802:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 809:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

00000810 <thread_yield>:

void thread_yield(void) {
 810:	55                   	push   %ebp
 811:	89 e5                	mov    %esp,%ebp
 813:	57                   	push   %edi
 814:	56                   	push   %esi
 815:	53                   	push   %ebx
 816:	83 ec 0c             	sub    $0xc,%esp
  struct thread *old_thread = current_thread;
 819:	8b 1d 60 0e 00 00    	mov    0xe60,%ebx
  
  // Mark current thread as RUNNABLE if it's not a ZOMBIE
  if (old_thread->state == RUNNING) {
 81f:	83 7b 04 02          	cmpl   $0x2,0x4(%ebx)
 823:	75 07                	jne    82c <thread_yield+0x1c>
    old_thread->state = RUNNABLE;
 825:	c7 43 04 01 00 00 00 	movl   $0x1,0x4(%ebx)
  }
  
  // Round-robin scheduler to pick next RUNNABLE thread
  int i = (old_thread - threads + 1) % MAX_THREADS;
 82c:	89 d9                	mov    %ebx,%ecx
 82e:	81 e9 80 0e 00 00    	sub    $0xe80,%ecx
 834:	c1 f9 02             	sar    $0x2,%ecx
 837:	69 c9 cd 28 ac dc    	imul   $0xdcac28cd,%ecx,%ecx
 83d:	8d 41 01             	lea    0x1(%ecx),%eax
 840:	eb 1e                	jmp    860 <thread_yield+0x50>
 842:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  while (i != (old_thread - threads)) {
    if (threads[i].state == RUNNABLE) {
 848:	69 d0 14 10 00 00    	imul   $0x1014,%eax,%edx
 84e:	83 ba 84 0e 00 00 01 	cmpl   $0x1,0xe84(%edx)
 855:	8d b2 80 0e 00 00    	lea    0xe80(%edx),%esi
 85b:	74 23                	je     880 <thread_yield+0x70>
      current_thread = &threads[i];
      current_thread->state = RUNNING;
      uswtch(&old_thread->context, current_thread->context);
      return;
    }
    i = (i + 1) % MAX_THREADS;
 85d:	83 c0 01             	add    $0x1,%eax
  int i = (old_thread - threads + 1) % MAX_THREADS;
 860:	99                   	cltd   
 861:	c1 ea 1d             	shr    $0x1d,%edx
 864:	01 d0                	add    %edx,%eax
 866:	83 e0 07             	and    $0x7,%eax
 869:	29 d0                	sub    %edx,%eax
  while (i != (old_thread - threads)) {
 86b:	39 c1                	cmp    %eax,%ecx
 86d:	75 d9                	jne    848 <thread_yield+0x38>
  }
}
 86f:	8d 65 f4             	lea    -0xc(%ebp),%esp
 872:	5b                   	pop    %ebx
 873:	5e                   	pop    %esi
 874:	5f                   	pop    %edi
 875:	5d                   	pop    %ebp
 876:	c3                   	ret    
 877:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 87e:	66 90                	xchg   %ax,%ax
      uswtch(&old_thread->context, current_thread->context);
 880:	83 ec 08             	sub    $0x8,%esp
 883:	81 c3 08 10 00 00    	add    $0x1008,%ebx
 889:	ff b2 88 1e 00 00    	push   0x1e88(%edx)
 88f:	53                   	push   %ebx
      current_thread = &threads[i];
 890:	89 35 60 0e 00 00    	mov    %esi,0xe60
      current_thread->state = RUNNING;
 896:	c7 82 84 0e 00 00 02 	movl   $0x2,0xe84(%edx)
 89d:	00 00 00 
      uswtch(&old_thread->context, current_thread->context);
 8a0:	e8 09 01 00 00       	call   9ae <uswtch>
      return;
 8a5:	83 c4 10             	add    $0x10,%esp
}
 8a8:	8d 65 f4             	lea    -0xc(%ebp),%esp
 8ab:	5b                   	pop    %ebx
 8ac:	5e                   	pop    %esi
 8ad:	5f                   	pop    %edi
 8ae:	5d                   	pop    %ebp
 8af:	c3                   	ret    

000008b0 <thread_stub>:
static void thread_stub(void) {
 8b0:	55                   	push   %ebp
 8b1:	89 e5                	mov    %esp,%ebp
 8b3:	83 ec 14             	sub    $0x14,%esp
  current_thread->fn(current_thread->arg);
 8b6:	a1 60 0e 00 00       	mov    0xe60,%eax
 8bb:	ff b0 10 10 00 00    	push   0x1010(%eax)
 8c1:	ff 90 0c 10 00 00    	call   *0x100c(%eax)
  current_thread->state = ZOMBIE;
 8c7:	a1 60 0e 00 00       	mov    0xe60,%eax
  thread_yield();
 8cc:	83 c4 10             	add    $0x10,%esp
  current_thread->state = ZOMBIE;
 8cf:	c7 40 04 03 00 00 00 	movl   $0x3,0x4(%eax)
}
 8d6:	c9                   	leave  
  thread_yield();
 8d7:	e9 34 ff ff ff       	jmp    810 <thread_yield>
 8dc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

000008e0 <thread_join>:

int thread_join(tid_t tid) {
 8e0:	55                   	push   %ebp
 8e1:	b8 80 0e 00 00       	mov    $0xe80,%eax
 8e6:	89 e5                	mov    %esp,%ebp
 8e8:	56                   	push   %esi
 8e9:	8b 55 08             	mov    0x8(%ebp),%edx
 8ec:	53                   	push   %ebx
  struct thread *t = 0;
  
  // Locate the thread by ID
  for (int i = 0; i < MAX_THREADS; i++) {
 8ed:	31 db                	xor    %ebx,%ebx
 8ef:	eb 14                	jmp    905 <thread_join+0x25>
 8f1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 8f8:	83 c3 01             	add    $0x1,%ebx
 8fb:	05 14 10 00 00       	add    $0x1014,%eax
 900:	83 fb 08             	cmp    $0x8,%ebx
 903:	74 4b                	je     950 <thread_join+0x70>
    if (threads[i].tid == tid && threads[i].state != FREE) {
 905:	39 10                	cmp    %edx,(%eax)
 907:	75 ef                	jne    8f8 <thread_join+0x18>
 909:	8b 48 04             	mov    0x4(%eax),%ecx
 90c:	85 c9                	test   %ecx,%ecx
 90e:	74 e8                	je     8f8 <thread_join+0x18>
  }
  
  if (!t) return -1;
  
  // Cooperatively yield until the target thread becomes a ZOMBIE
  while (t->state != ZOMBIE) {
 910:	83 f9 03             	cmp    $0x3,%ecx
 913:	74 1e                	je     933 <thread_join+0x53>
 915:	69 f3 14 10 00 00    	imul   $0x1014,%ebx,%esi
 91b:	81 c6 80 0e 00 00    	add    $0xe80,%esi
 921:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    thread_yield();
 928:	e8 e3 fe ff ff       	call   810 <thread_yield>
  while (t->state != ZOMBIE) {
 92d:	83 7e 04 03          	cmpl   $0x3,0x4(%esi)
 931:	75 f5                	jne    928 <thread_join+0x48>
  }
  
  // Clean up the ZOMBIE thread
  t->state = FREE;
 933:	69 db 14 10 00 00    	imul   $0x1014,%ebx,%ebx
  return 0;
 939:	31 c0                	xor    %eax,%eax
  t->state = FREE;
 93b:	c7 83 84 0e 00 00 00 	movl   $0x0,0xe84(%ebx)
 942:	00 00 00 
 945:	5b                   	pop    %ebx
 946:	5e                   	pop    %esi
 947:	5d                   	pop    %ebp
 948:	c3                   	ret    
 949:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 950:	5b                   	pop    %ebx
  if (!t) return -1;
 951:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
 956:	5e                   	pop    %esi
 957:	5d                   	pop    %ebp
 958:	c3                   	ret    
 959:	66 90                	xchg   %ax,%ax
 95b:	66 90                	xchg   %ax,%ax
 95d:	66 90                	xchg   %ax,%ax
 95f:	90                   	nop

00000960 <mutex_init>:
#include "stat.h"
#include "user.h"
#include "uthread.h"
#include "umutex.h"

void mutex_init(umutex_t *m){ m->locked = 0; }
 960:	55                   	push   %ebp
 961:	89 e5                	mov    %esp,%ebp
 963:	8b 45 08             	mov    0x8(%ebp),%eax
 966:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
 96c:	5d                   	pop    %ebp
 96d:	c3                   	ret    
 96e:	66 90                	xchg   %ax,%ax

00000970 <mutex_lock>:
void mutex_lock(umutex_t *m){ while(m->locked){ thread_yield(); } m->locked = 1; }
 970:	55                   	push   %ebp
 971:	89 e5                	mov    %esp,%ebp
 973:	53                   	push   %ebx
 974:	83 ec 04             	sub    $0x4,%esp
 977:	8b 5d 08             	mov    0x8(%ebp),%ebx
 97a:	8b 03                	mov    (%ebx),%eax
 97c:	85 c0                	test   %eax,%eax
 97e:	74 0b                	je     98b <mutex_lock+0x1b>
 980:	e8 8b fe ff ff       	call   810 <thread_yield>
 985:	8b 03                	mov    (%ebx),%eax
 987:	85 c0                	test   %eax,%eax
 989:	75 f5                	jne    980 <mutex_lock+0x10>
 98b:	c7 03 01 00 00 00    	movl   $0x1,(%ebx)
 991:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 994:	c9                   	leave  
 995:	c3                   	ret    
 996:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 99d:	8d 76 00             	lea    0x0(%esi),%esi

000009a0 <mutex_unlock>:
 9a0:	55                   	push   %ebp
 9a1:	89 e5                	mov    %esp,%ebp
 9a3:	8b 45 08             	mov    0x8(%ebp),%eax
 9a6:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
 9ac:	5d                   	pop    %ebp
 9ad:	c3                   	ret    

000009ae <uswtch>:
# User-space context switch for xv6 x86
# void uswtch(struct context **old, struct context *new);

.globl uswtch
uswtch:
  movl 4(%esp), %eax
 9ae:	8b 44 24 04          	mov    0x4(%esp),%eax
  movl 8(%esp), %edx
 9b2:	8b 54 24 08          	mov    0x8(%esp),%edx

  pushl %ebp
 9b6:	55                   	push   %ebp
  pushl %ebx
 9b7:	53                   	push   %ebx
  pushl %esi
 9b8:	56                   	push   %esi
  pushl %edi
 9b9:	57                   	push   %edi

  movl %esp, (%eax)
 9ba:	89 20                	mov    %esp,(%eax)
  movl %edx, %esp
 9bc:	89 d4                	mov    %edx,%esp

  popl %edi
 9be:	5f                   	pop    %edi
  popl %esi
 9bf:	5e                   	pop    %esi
  popl %ebx
 9c0:	5b                   	pop    %ebx
  popl %ebp
 9c1:	5d                   	pop    %ebp
  ret
 9c2:	c3                   	ret    
