
_test_pc:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
    thread_yield();
  }
}

int main(int argc, char *argv[])
{
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	push   -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	57                   	push   %edi
   e:	56                   	push   %esi
   f:	53                   	push   %ebx
  10:	51                   	push   %ecx
  11:	83 ec 10             	sub    $0x10,%esp
  printf(1, "Starting test...\n");
  14:	68 6f 0b 00 00       	push   $0xb6f
  19:	6a 01                	push   $0x1
  1b:	e8 80 05 00 00       	call   5a0 <printf>

  thread_init();
  20:	e8 ab 08 00 00       	call   8d0 <thread_init>
  mutex_init(&mu);
  25:	c7 04 24 40 10 00 00 	movl   $0x1040,(%esp)
  2c:	e8 bf 0a 00 00       	call   af0 <mutex_init>

  tid_t prod1_tid = thread_create(producer, (void*)1);
  31:	58                   	pop    %eax
  32:	5a                   	pop    %edx
  33:	6a 01                	push   $0x1
  35:	68 50 01 00 00       	push   $0x150
  3a:	e8 b1 08 00 00       	call   8f0 <thread_create>
  tid_t prod2_tid = thread_create(producer, (void*)2);
  3f:	59                   	pop    %ecx
  40:	5b                   	pop    %ebx
  41:	6a 02                	push   $0x2
  43:	68 50 01 00 00       	push   $0x150
  tid_t prod1_tid = thread_create(producer, (void*)1);
  48:	89 c7                	mov    %eax,%edi
  tid_t prod2_tid = thread_create(producer, (void*)2);
  4a:	e8 a1 08 00 00       	call   8f0 <thread_create>
  4f:	89 c6                	mov    %eax,%esi
  
  tid_t cons_tid = thread_create(consumer, (void*)3);
  51:	58                   	pop    %eax
  52:	5a                   	pop    %edx
  53:	6a 03                	push   $0x3
  55:	68 90 00 00 00       	push   $0x90
  5a:	e8 91 08 00 00       	call   8f0 <thread_create>

  thread_join(prod1_tid);
  5f:	89 3c 24             	mov    %edi,(%esp)
  tid_t cons_tid = thread_create(consumer, (void*)3);
  62:	89 c3                	mov    %eax,%ebx
  thread_join(prod1_tid);
  64:	e8 07 0a 00 00       	call   a70 <thread_join>
  thread_join(prod2_tid);
  69:	89 34 24             	mov    %esi,(%esp)
  6c:	e8 ff 09 00 00       	call   a70 <thread_join>
  thread_join(cons_tid);
  71:	89 1c 24             	mov    %ebx,(%esp)
  74:	e8 f7 09 00 00       	call   a70 <thread_join>

  printf(1, "test_pc: test successful\n");
  79:	59                   	pop    %ecx
  7a:	5b                   	pop    %ebx
  7b:	68 81 0b 00 00       	push   $0xb81
  80:	6a 01                	push   $0x1
  82:	e8 19 05 00 00       	call   5a0 <printf>
  
  exit();
  87:	e8 b7 03 00 00       	call   443 <exit>
  8c:	66 90                	xchg   %ax,%ax
  8e:	66 90                	xchg   %ax,%ax

00000090 <consumer>:
static void consumer(void *arg){
  90:	55                   	push   %ebp
  91:	89 e5                	mov    %esp,%ebp
  93:	56                   	push   %esi
  94:	53                   	push   %ebx
  int got = 0;
  95:	31 db                	xor    %ebx,%ebx
  97:	eb 1c                	jmp    b5 <consumer+0x25>
  99:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
      mutex_unlock(&mu);
  a0:	83 ec 0c             	sub    $0xc,%esp
  a3:	68 40 10 00 00       	push   $0x1040
  a8:	e8 83 0a 00 00       	call   b30 <mutex_unlock>
      thread_yield(); // Buffer empty, yield and try again
  ad:	e8 ee 08 00 00       	call   9a0 <thread_yield>
      mutex_lock(&mu);
  b2:	83 c4 10             	add    $0x10,%esp
  b5:	83 ec 0c             	sub    $0xc,%esp
  b8:	68 40 10 00 00       	push   $0x1040
  bd:	e8 3e 0a 00 00       	call   b00 <mutex_lock>
      if(count > 0){
  c2:	a1 44 10 00 00       	mov    0x1044,%eax
  c7:	83 c4 10             	add    $0x10,%esp
  ca:	85 c0                	test   %eax,%eax
  cc:	7e d2                	jle    a0 <consumer+0x10>
        int x = buf[head];
  ce:	8b 15 4c 10 00 00    	mov    0x104c,%edx
        count--;
  d4:	83 e8 01             	sub    $0x1,%eax
        got++;
  d7:	83 c3 01             	add    $0x1,%ebx
        count--;
  da:	a3 44 10 00 00       	mov    %eax,0x1044
        got++;
  df:	69 c3 29 5c 8f c2    	imul   $0xc28f5c29,%ebx,%eax
        int x = buf[head];
  e5:	8b 0c 95 60 10 00 00 	mov    0x1060(,%edx,4),%ecx
        head = (head+1)%N;
  ec:	83 c2 01             	add    $0x1,%edx
  ef:	89 d6                	mov    %edx,%esi
  f1:	c1 fe 1f             	sar    $0x1f,%esi
        got++;
  f4:	d1 c8                	ror    %eax
        head = (head+1)%N;
  f6:	c1 ee 1d             	shr    $0x1d,%esi
  f9:	01 f2                	add    %esi,%edx
  fb:	83 e2 07             	and    $0x7,%edx
  fe:	29 f2                	sub    %esi,%edx
 100:	89 15 4c 10 00 00    	mov    %edx,0x104c
        if(got % 50 == 0) printf(1, "consumer got %d (last=%d)\n", got, x);
 106:	3d 51 b8 1e 05       	cmp    $0x51eb851,%eax
 10b:	76 2b                	jbe    138 <consumer+0xa8>
        mutex_unlock(&mu);
 10d:	83 ec 0c             	sub    $0xc,%esp
 110:	68 40 10 00 00       	push   $0x1040
 115:	e8 16 0a 00 00       	call   b30 <mutex_unlock>
    thread_yield();
 11a:	e8 81 08 00 00       	call   9a0 <thread_yield>
  while(got < 200){
 11f:	83 c4 10             	add    $0x10,%esp
 122:	81 fb c8 00 00 00    	cmp    $0xc8,%ebx
 128:	75 8b                	jne    b5 <consumer+0x25>
}
 12a:	8d 65 f8             	lea    -0x8(%ebp),%esp
 12d:	5b                   	pop    %ebx
 12e:	5e                   	pop    %esi
 12f:	5d                   	pop    %ebp
 130:	c3                   	ret    
 131:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
        if(got % 50 == 0) printf(1, "consumer got %d (last=%d)\n", got, x);
 138:	51                   	push   %ecx
 139:	53                   	push   %ebx
 13a:	68 54 0b 00 00       	push   $0xb54
 13f:	6a 01                	push   $0x1
 141:	e8 5a 04 00 00       	call   5a0 <printf>
 146:	83 c4 10             	add    $0x10,%esp
 149:	eb c2                	jmp    10d <consumer+0x7d>
 14b:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
 14f:	90                   	nop

00000150 <producer>:
static void producer(void *arg){
 150:	55                   	push   %ebp
 151:	89 e5                	mov    %esp,%ebp
 153:	56                   	push   %esi
 154:	53                   	push   %ebx
        buf[tail] = id*1000 + i;
 155:	69 5d 08 e8 03 00 00 	imul   $0x3e8,0x8(%ebp),%ebx
 15c:	8d 73 64             	lea    0x64(%ebx),%esi
 15f:	eb 1c                	jmp    17d <producer+0x2d>
 161:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
      mutex_unlock(&mu);
 168:	83 ec 0c             	sub    $0xc,%esp
 16b:	68 40 10 00 00       	push   $0x1040
 170:	e8 bb 09 00 00       	call   b30 <mutex_unlock>
      thread_yield(); // Buffer full, yield and try again
 175:	e8 26 08 00 00       	call   9a0 <thread_yield>
      mutex_lock(&mu);
 17a:	83 c4 10             	add    $0x10,%esp
 17d:	83 ec 0c             	sub    $0xc,%esp
 180:	68 40 10 00 00       	push   $0x1040
 185:	e8 76 09 00 00       	call   b00 <mutex_lock>
      if(count < N){
 18a:	a1 44 10 00 00       	mov    0x1044,%eax
 18f:	83 c4 10             	add    $0x10,%esp
 192:	83 f8 07             	cmp    $0x7,%eax
 195:	7f d1                	jg     168 <producer+0x18>
        buf[tail] = id*1000 + i;
 197:	8b 15 48 10 00 00    	mov    0x1048,%edx
        mutex_unlock(&mu);
 19d:	83 ec 0c             	sub    $0xc,%esp
        count++;
 1a0:	83 c0 01             	add    $0x1,%eax
        mutex_unlock(&mu);
 1a3:	68 40 10 00 00       	push   $0x1040
        buf[tail] = id*1000 + i;
 1a8:	89 1c 95 60 10 00 00 	mov    %ebx,0x1060(,%edx,4)
        tail = (tail+1)%N;
 1af:	83 c2 01             	add    $0x1,%edx
  for(int i=0;i<100;i++){
 1b2:	83 c3 01             	add    $0x1,%ebx
        tail = (tail+1)%N;
 1b5:	89 d1                	mov    %edx,%ecx
        count++;
 1b7:	a3 44 10 00 00       	mov    %eax,0x1044
        tail = (tail+1)%N;
 1bc:	c1 f9 1f             	sar    $0x1f,%ecx
 1bf:	c1 e9 1d             	shr    $0x1d,%ecx
 1c2:	01 ca                	add    %ecx,%edx
 1c4:	83 e2 07             	and    $0x7,%edx
 1c7:	29 ca                	sub    %ecx,%edx
 1c9:	89 15 48 10 00 00    	mov    %edx,0x1048
        mutex_unlock(&mu);
 1cf:	e8 5c 09 00 00       	call   b30 <mutex_unlock>
    thread_yield();
 1d4:	e8 c7 07 00 00       	call   9a0 <thread_yield>
  for(int i=0;i<100;i++){
 1d9:	83 c4 10             	add    $0x10,%esp
 1dc:	39 f3                	cmp    %esi,%ebx
 1de:	75 9d                	jne    17d <producer+0x2d>
}
 1e0:	8d 65 f8             	lea    -0x8(%ebp),%esp
 1e3:	5b                   	pop    %ebx
 1e4:	5e                   	pop    %esi
 1e5:	5d                   	pop    %ebp
 1e6:	c3                   	ret    
 1e7:	66 90                	xchg   %ax,%ax
 1e9:	66 90                	xchg   %ax,%ax
 1eb:	66 90                	xchg   %ax,%ax
 1ed:	66 90                	xchg   %ax,%ax
 1ef:	90                   	nop

000001f0 <strcpy>:
#include "user.h"
#include "x86.h"

char*
strcpy(char *s, const char *t)
{
 1f0:	55                   	push   %ebp
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 1f1:	31 c0                	xor    %eax,%eax
{
 1f3:	89 e5                	mov    %esp,%ebp
 1f5:	53                   	push   %ebx
 1f6:	8b 4d 08             	mov    0x8(%ebp),%ecx
 1f9:	8b 5d 0c             	mov    0xc(%ebp),%ebx
 1fc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  while((*s++ = *t++) != 0)
 200:	0f b6 14 03          	movzbl (%ebx,%eax,1),%edx
 204:	88 14 01             	mov    %dl,(%ecx,%eax,1)
 207:	83 c0 01             	add    $0x1,%eax
 20a:	84 d2                	test   %dl,%dl
 20c:	75 f2                	jne    200 <strcpy+0x10>
    ;
  return os;
}
 20e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 211:	89 c8                	mov    %ecx,%eax
 213:	c9                   	leave  
 214:	c3                   	ret    
 215:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 21c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000220 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 220:	55                   	push   %ebp
 221:	89 e5                	mov    %esp,%ebp
 223:	53                   	push   %ebx
 224:	8b 55 08             	mov    0x8(%ebp),%edx
 227:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  while(*p && *p == *q)
 22a:	0f b6 02             	movzbl (%edx),%eax
 22d:	84 c0                	test   %al,%al
 22f:	75 17                	jne    248 <strcmp+0x28>
 231:	eb 3a                	jmp    26d <strcmp+0x4d>
 233:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
 237:	90                   	nop
 238:	0f b6 42 01          	movzbl 0x1(%edx),%eax
    p++, q++;
 23c:	83 c2 01             	add    $0x1,%edx
 23f:	8d 59 01             	lea    0x1(%ecx),%ebx
  while(*p && *p == *q)
 242:	84 c0                	test   %al,%al
 244:	74 1a                	je     260 <strcmp+0x40>
    p++, q++;
 246:	89 d9                	mov    %ebx,%ecx
  while(*p && *p == *q)
 248:	0f b6 19             	movzbl (%ecx),%ebx
 24b:	38 c3                	cmp    %al,%bl
 24d:	74 e9                	je     238 <strcmp+0x18>
  return (uchar)*p - (uchar)*q;
 24f:	29 d8                	sub    %ebx,%eax
}
 251:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 254:	c9                   	leave  
 255:	c3                   	ret    
 256:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 25d:	8d 76 00             	lea    0x0(%esi),%esi
  return (uchar)*p - (uchar)*q;
 260:	0f b6 59 01          	movzbl 0x1(%ecx),%ebx
 264:	31 c0                	xor    %eax,%eax
 266:	29 d8                	sub    %ebx,%eax
}
 268:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 26b:	c9                   	leave  
 26c:	c3                   	ret    
  return (uchar)*p - (uchar)*q;
 26d:	0f b6 19             	movzbl (%ecx),%ebx
 270:	31 c0                	xor    %eax,%eax
 272:	eb db                	jmp    24f <strcmp+0x2f>
 274:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 27b:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
 27f:	90                   	nop

00000280 <strlen>:

uint
strlen(const char *s)
{
 280:	55                   	push   %ebp
 281:	89 e5                	mov    %esp,%ebp
 283:	8b 55 08             	mov    0x8(%ebp),%edx
  int n;

  for(n = 0; s[n]; n++)
 286:	80 3a 00             	cmpb   $0x0,(%edx)
 289:	74 15                	je     2a0 <strlen+0x20>
 28b:	31 c0                	xor    %eax,%eax
 28d:	8d 76 00             	lea    0x0(%esi),%esi
 290:	83 c0 01             	add    $0x1,%eax
 293:	80 3c 02 00          	cmpb   $0x0,(%edx,%eax,1)
 297:	89 c1                	mov    %eax,%ecx
 299:	75 f5                	jne    290 <strlen+0x10>
    ;
  return n;
}
 29b:	89 c8                	mov    %ecx,%eax
 29d:	5d                   	pop    %ebp
 29e:	c3                   	ret    
 29f:	90                   	nop
  for(n = 0; s[n]; n++)
 2a0:	31 c9                	xor    %ecx,%ecx
}
 2a2:	5d                   	pop    %ebp
 2a3:	89 c8                	mov    %ecx,%eax
 2a5:	c3                   	ret    
 2a6:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 2ad:	8d 76 00             	lea    0x0(%esi),%esi

000002b0 <memset>:

void*
memset(void *dst, int c, uint n)
{
 2b0:	55                   	push   %ebp
 2b1:	89 e5                	mov    %esp,%ebp
 2b3:	57                   	push   %edi
 2b4:	8b 55 08             	mov    0x8(%ebp),%edx
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
 2b7:	8b 4d 10             	mov    0x10(%ebp),%ecx
 2ba:	8b 45 0c             	mov    0xc(%ebp),%eax
 2bd:	89 d7                	mov    %edx,%edi
 2bf:	fc                   	cld    
 2c0:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
 2c2:	8b 7d fc             	mov    -0x4(%ebp),%edi
 2c5:	89 d0                	mov    %edx,%eax
 2c7:	c9                   	leave  
 2c8:	c3                   	ret    
 2c9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

000002d0 <strchr>:

char*
strchr(const char *s, char c)
{
 2d0:	55                   	push   %ebp
 2d1:	89 e5                	mov    %esp,%ebp
 2d3:	8b 45 08             	mov    0x8(%ebp),%eax
 2d6:	0f b6 4d 0c          	movzbl 0xc(%ebp),%ecx
  for(; *s; s++)
 2da:	0f b6 10             	movzbl (%eax),%edx
 2dd:	84 d2                	test   %dl,%dl
 2df:	75 12                	jne    2f3 <strchr+0x23>
 2e1:	eb 1d                	jmp    300 <strchr+0x30>
 2e3:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
 2e7:	90                   	nop
 2e8:	0f b6 50 01          	movzbl 0x1(%eax),%edx
 2ec:	83 c0 01             	add    $0x1,%eax
 2ef:	84 d2                	test   %dl,%dl
 2f1:	74 0d                	je     300 <strchr+0x30>
    if(*s == c)
 2f3:	38 d1                	cmp    %dl,%cl
 2f5:	75 f1                	jne    2e8 <strchr+0x18>
      return (char*)s;
  return 0;
}
 2f7:	5d                   	pop    %ebp
 2f8:	c3                   	ret    
 2f9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  return 0;
 300:	31 c0                	xor    %eax,%eax
}
 302:	5d                   	pop    %ebp
 303:	c3                   	ret    
 304:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 30b:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
 30f:	90                   	nop

00000310 <gets>:

char*
gets(char *buf, int max)
{
 310:	55                   	push   %ebp
 311:	89 e5                	mov    %esp,%ebp
 313:	57                   	push   %edi
 314:	56                   	push   %esi
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
    cc = read(0, &c, 1);
 315:	8d 7d e7             	lea    -0x19(%ebp),%edi
{
 318:	53                   	push   %ebx
  for(i=0; i+1 < max; ){
 319:	31 db                	xor    %ebx,%ebx
{
 31b:	83 ec 1c             	sub    $0x1c,%esp
  for(i=0; i+1 < max; ){
 31e:	eb 27                	jmp    347 <gets+0x37>
    cc = read(0, &c, 1);
 320:	83 ec 04             	sub    $0x4,%esp
 323:	6a 01                	push   $0x1
 325:	57                   	push   %edi
 326:	6a 00                	push   $0x0
 328:	e8 2e 01 00 00       	call   45b <read>
    if(cc < 1)
 32d:	83 c4 10             	add    $0x10,%esp
 330:	85 c0                	test   %eax,%eax
 332:	7e 1d                	jle    351 <gets+0x41>
      break;
    buf[i++] = c;
 334:	0f b6 45 e7          	movzbl -0x19(%ebp),%eax
 338:	8b 55 08             	mov    0x8(%ebp),%edx
 33b:	88 44 1a ff          	mov    %al,-0x1(%edx,%ebx,1)
    if(c == '\n' || c == '\r')
 33f:	3c 0a                	cmp    $0xa,%al
 341:	74 1d                	je     360 <gets+0x50>
 343:	3c 0d                	cmp    $0xd,%al
 345:	74 19                	je     360 <gets+0x50>
  for(i=0; i+1 < max; ){
 347:	89 de                	mov    %ebx,%esi
 349:	83 c3 01             	add    $0x1,%ebx
 34c:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 34f:	7c cf                	jl     320 <gets+0x10>
      break;
  }
  buf[i] = '\0';
 351:	8b 45 08             	mov    0x8(%ebp),%eax
 354:	c6 04 30 00          	movb   $0x0,(%eax,%esi,1)
  return buf;
}
 358:	8d 65 f4             	lea    -0xc(%ebp),%esp
 35b:	5b                   	pop    %ebx
 35c:	5e                   	pop    %esi
 35d:	5f                   	pop    %edi
 35e:	5d                   	pop    %ebp
 35f:	c3                   	ret    
  buf[i] = '\0';
 360:	8b 45 08             	mov    0x8(%ebp),%eax
 363:	89 de                	mov    %ebx,%esi
 365:	c6 04 30 00          	movb   $0x0,(%eax,%esi,1)
}
 369:	8d 65 f4             	lea    -0xc(%ebp),%esp
 36c:	5b                   	pop    %ebx
 36d:	5e                   	pop    %esi
 36e:	5f                   	pop    %edi
 36f:	5d                   	pop    %ebp
 370:	c3                   	ret    
 371:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 378:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 37f:	90                   	nop

00000380 <stat>:

int
stat(const char *n, struct stat *st)
{
 380:	55                   	push   %ebp
 381:	89 e5                	mov    %esp,%ebp
 383:	56                   	push   %esi
 384:	53                   	push   %ebx
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 385:	83 ec 08             	sub    $0x8,%esp
 388:	6a 00                	push   $0x0
 38a:	ff 75 08             	push   0x8(%ebp)
 38d:	e8 f1 00 00 00       	call   483 <open>
  if(fd < 0)
 392:	83 c4 10             	add    $0x10,%esp
 395:	85 c0                	test   %eax,%eax
 397:	78 27                	js     3c0 <stat+0x40>
    return -1;
  r = fstat(fd, st);
 399:	83 ec 08             	sub    $0x8,%esp
 39c:	ff 75 0c             	push   0xc(%ebp)
 39f:	89 c3                	mov    %eax,%ebx
 3a1:	50                   	push   %eax
 3a2:	e8 f4 00 00 00       	call   49b <fstat>
  close(fd);
 3a7:	89 1c 24             	mov    %ebx,(%esp)
  r = fstat(fd, st);
 3aa:	89 c6                	mov    %eax,%esi
  close(fd);
 3ac:	e8 ba 00 00 00       	call   46b <close>
  return r;
 3b1:	83 c4 10             	add    $0x10,%esp
}
 3b4:	8d 65 f8             	lea    -0x8(%ebp),%esp
 3b7:	89 f0                	mov    %esi,%eax
 3b9:	5b                   	pop    %ebx
 3ba:	5e                   	pop    %esi
 3bb:	5d                   	pop    %ebp
 3bc:	c3                   	ret    
 3bd:	8d 76 00             	lea    0x0(%esi),%esi
    return -1;
 3c0:	be ff ff ff ff       	mov    $0xffffffff,%esi
 3c5:	eb ed                	jmp    3b4 <stat+0x34>
 3c7:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 3ce:	66 90                	xchg   %ax,%ax

000003d0 <atoi>:

int
atoi(const char *s)
{
 3d0:	55                   	push   %ebp
 3d1:	89 e5                	mov    %esp,%ebp
 3d3:	53                   	push   %ebx
 3d4:	8b 55 08             	mov    0x8(%ebp),%edx
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 3d7:	0f be 02             	movsbl (%edx),%eax
 3da:	8d 48 d0             	lea    -0x30(%eax),%ecx
 3dd:	80 f9 09             	cmp    $0x9,%cl
  n = 0;
 3e0:	b9 00 00 00 00       	mov    $0x0,%ecx
  while('0' <= *s && *s <= '9')
 3e5:	77 1e                	ja     405 <atoi+0x35>
 3e7:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 3ee:	66 90                	xchg   %ax,%ax
    n = n*10 + *s++ - '0';
 3f0:	83 c2 01             	add    $0x1,%edx
 3f3:	8d 0c 89             	lea    (%ecx,%ecx,4),%ecx
 3f6:	8d 4c 48 d0          	lea    -0x30(%eax,%ecx,2),%ecx
  while('0' <= *s && *s <= '9')
 3fa:	0f be 02             	movsbl (%edx),%eax
 3fd:	8d 58 d0             	lea    -0x30(%eax),%ebx
 400:	80 fb 09             	cmp    $0x9,%bl
 403:	76 eb                	jbe    3f0 <atoi+0x20>
  return n;
}
 405:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 408:	89 c8                	mov    %ecx,%eax
 40a:	c9                   	leave  
 40b:	c3                   	ret    
 40c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000410 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 410:	55                   	push   %ebp
 411:	89 e5                	mov    %esp,%ebp
 413:	57                   	push   %edi
 414:	8b 45 10             	mov    0x10(%ebp),%eax
 417:	8b 55 08             	mov    0x8(%ebp),%edx
 41a:	56                   	push   %esi
 41b:	8b 75 0c             	mov    0xc(%ebp),%esi
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  while(n-- > 0)
 41e:	85 c0                	test   %eax,%eax
 420:	7e 13                	jle    435 <memmove+0x25>
 422:	01 d0                	add    %edx,%eax
  dst = vdst;
 424:	89 d7                	mov    %edx,%edi
 426:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 42d:	8d 76 00             	lea    0x0(%esi),%esi
    *dst++ = *src++;
 430:	a4                   	movsb  %ds:(%esi),%es:(%edi)
  while(n-- > 0)
 431:	39 f8                	cmp    %edi,%eax
 433:	75 fb                	jne    430 <memmove+0x20>
  return vdst;
}
 435:	5e                   	pop    %esi
 436:	89 d0                	mov    %edx,%eax
 438:	5f                   	pop    %edi
 439:	5d                   	pop    %ebp
 43a:	c3                   	ret    

0000043b <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 43b:	b8 01 00 00 00       	mov    $0x1,%eax
 440:	cd 40                	int    $0x40
 442:	c3                   	ret    

00000443 <exit>:
SYSCALL(exit)
 443:	b8 02 00 00 00       	mov    $0x2,%eax
 448:	cd 40                	int    $0x40
 44a:	c3                   	ret    

0000044b <wait>:
SYSCALL(wait)
 44b:	b8 03 00 00 00       	mov    $0x3,%eax
 450:	cd 40                	int    $0x40
 452:	c3                   	ret    

00000453 <pipe>:
SYSCALL(pipe)
 453:	b8 04 00 00 00       	mov    $0x4,%eax
 458:	cd 40                	int    $0x40
 45a:	c3                   	ret    

0000045b <read>:
SYSCALL(read)
 45b:	b8 05 00 00 00       	mov    $0x5,%eax
 460:	cd 40                	int    $0x40
 462:	c3                   	ret    

00000463 <write>:
SYSCALL(write)
 463:	b8 10 00 00 00       	mov    $0x10,%eax
 468:	cd 40                	int    $0x40
 46a:	c3                   	ret    

0000046b <close>:
SYSCALL(close)
 46b:	b8 15 00 00 00       	mov    $0x15,%eax
 470:	cd 40                	int    $0x40
 472:	c3                   	ret    

00000473 <kill>:
SYSCALL(kill)
 473:	b8 06 00 00 00       	mov    $0x6,%eax
 478:	cd 40                	int    $0x40
 47a:	c3                   	ret    

0000047b <exec>:
SYSCALL(exec)
 47b:	b8 07 00 00 00       	mov    $0x7,%eax
 480:	cd 40                	int    $0x40
 482:	c3                   	ret    

00000483 <open>:
SYSCALL(open)
 483:	b8 0f 00 00 00       	mov    $0xf,%eax
 488:	cd 40                	int    $0x40
 48a:	c3                   	ret    

0000048b <mknod>:
SYSCALL(mknod)
 48b:	b8 11 00 00 00       	mov    $0x11,%eax
 490:	cd 40                	int    $0x40
 492:	c3                   	ret    

00000493 <unlink>:
SYSCALL(unlink)
 493:	b8 12 00 00 00       	mov    $0x12,%eax
 498:	cd 40                	int    $0x40
 49a:	c3                   	ret    

0000049b <fstat>:
SYSCALL(fstat)
 49b:	b8 08 00 00 00       	mov    $0x8,%eax
 4a0:	cd 40                	int    $0x40
 4a2:	c3                   	ret    

000004a3 <link>:
SYSCALL(link)
 4a3:	b8 13 00 00 00       	mov    $0x13,%eax
 4a8:	cd 40                	int    $0x40
 4aa:	c3                   	ret    

000004ab <mkdir>:
SYSCALL(mkdir)
 4ab:	b8 14 00 00 00       	mov    $0x14,%eax
 4b0:	cd 40                	int    $0x40
 4b2:	c3                   	ret    

000004b3 <chdir>:
SYSCALL(chdir)
 4b3:	b8 09 00 00 00       	mov    $0x9,%eax
 4b8:	cd 40                	int    $0x40
 4ba:	c3                   	ret    

000004bb <dup>:
SYSCALL(dup)
 4bb:	b8 0a 00 00 00       	mov    $0xa,%eax
 4c0:	cd 40                	int    $0x40
 4c2:	c3                   	ret    

000004c3 <getpid>:
SYSCALL(getpid)
 4c3:	b8 0b 00 00 00       	mov    $0xb,%eax
 4c8:	cd 40                	int    $0x40
 4ca:	c3                   	ret    

000004cb <sbrk>:
SYSCALL(sbrk)
 4cb:	b8 0c 00 00 00       	mov    $0xc,%eax
 4d0:	cd 40                	int    $0x40
 4d2:	c3                   	ret    

000004d3 <sleep>:
SYSCALL(sleep)
 4d3:	b8 0d 00 00 00       	mov    $0xd,%eax
 4d8:	cd 40                	int    $0x40
 4da:	c3                   	ret    

000004db <uptime>:
SYSCALL(uptime)
 4db:	b8 0e 00 00 00       	mov    $0xe,%eax
 4e0:	cd 40                	int    $0x40
 4e2:	c3                   	ret    
 4e3:	66 90                	xchg   %ax,%ax
 4e5:	66 90                	xchg   %ax,%ax
 4e7:	66 90                	xchg   %ax,%ax
 4e9:	66 90                	xchg   %ax,%ax
 4eb:	66 90                	xchg   %ax,%ax
 4ed:	66 90                	xchg   %ax,%ax
 4ef:	90                   	nop

000004f0 <printint>:
  write(fd, &c, 1);
}

static void
printint(int fd, int xx, int base, int sgn)
{
 4f0:	55                   	push   %ebp
 4f1:	89 e5                	mov    %esp,%ebp
 4f3:	57                   	push   %edi
 4f4:	56                   	push   %esi
 4f5:	53                   	push   %ebx
 4f6:	83 ec 3c             	sub    $0x3c,%esp
 4f9:	89 4d c4             	mov    %ecx,-0x3c(%ebp)
  uint x;

  neg = 0;
  if(sgn && xx < 0){
    neg = 1;
    x = -xx;
 4fc:	89 d1                	mov    %edx,%ecx
{
 4fe:	89 45 b8             	mov    %eax,-0x48(%ebp)
  if(sgn && xx < 0){
 501:	85 d2                	test   %edx,%edx
 503:	0f 89 7f 00 00 00    	jns    588 <printint+0x98>
 509:	f6 45 08 01          	testb  $0x1,0x8(%ebp)
 50d:	74 79                	je     588 <printint+0x98>
    neg = 1;
 50f:	c7 45 bc 01 00 00 00 	movl   $0x1,-0x44(%ebp)
    x = -xx;
 516:	f7 d9                	neg    %ecx
  } else {
    x = xx;
  }

  i = 0;
 518:	31 db                	xor    %ebx,%ebx
 51a:	8d 75 d7             	lea    -0x29(%ebp),%esi
 51d:	8d 76 00             	lea    0x0(%esi),%esi
  do{
    buf[i++] = digits[x % base];
 520:	89 c8                	mov    %ecx,%eax
 522:	31 d2                	xor    %edx,%edx
 524:	89 cf                	mov    %ecx,%edi
 526:	f7 75 c4             	divl   -0x3c(%ebp)
 529:	0f b6 92 fc 0b 00 00 	movzbl 0xbfc(%edx),%edx
 530:	89 45 c0             	mov    %eax,-0x40(%ebp)
 533:	89 d8                	mov    %ebx,%eax
 535:	8d 5b 01             	lea    0x1(%ebx),%ebx
  }while((x /= base) != 0);
 538:	8b 4d c0             	mov    -0x40(%ebp),%ecx
    buf[i++] = digits[x % base];
 53b:	88 14 1e             	mov    %dl,(%esi,%ebx,1)
  }while((x /= base) != 0);
 53e:	39 7d c4             	cmp    %edi,-0x3c(%ebp)
 541:	76 dd                	jbe    520 <printint+0x30>
  if(neg)
 543:	8b 4d bc             	mov    -0x44(%ebp),%ecx
 546:	85 c9                	test   %ecx,%ecx
 548:	74 0c                	je     556 <printint+0x66>
    buf[i++] = '-';
 54a:	c6 44 1d d8 2d       	movb   $0x2d,-0x28(%ebp,%ebx,1)
    buf[i++] = digits[x % base];
 54f:	89 d8                	mov    %ebx,%eax
    buf[i++] = '-';
 551:	ba 2d 00 00 00       	mov    $0x2d,%edx

  while(--i >= 0)
 556:	8b 7d b8             	mov    -0x48(%ebp),%edi
 559:	8d 5c 05 d7          	lea    -0x29(%ebp,%eax,1),%ebx
 55d:	eb 07                	jmp    566 <printint+0x76>
 55f:	90                   	nop
    putc(fd, buf[i]);
 560:	0f b6 13             	movzbl (%ebx),%edx
 563:	83 eb 01             	sub    $0x1,%ebx
  write(fd, &c, 1);
 566:	83 ec 04             	sub    $0x4,%esp
 569:	88 55 d7             	mov    %dl,-0x29(%ebp)
 56c:	6a 01                	push   $0x1
 56e:	56                   	push   %esi
 56f:	57                   	push   %edi
 570:	e8 ee fe ff ff       	call   463 <write>
  while(--i >= 0)
 575:	83 c4 10             	add    $0x10,%esp
 578:	39 de                	cmp    %ebx,%esi
 57a:	75 e4                	jne    560 <printint+0x70>
}
 57c:	8d 65 f4             	lea    -0xc(%ebp),%esp
 57f:	5b                   	pop    %ebx
 580:	5e                   	pop    %esi
 581:	5f                   	pop    %edi
 582:	5d                   	pop    %ebp
 583:	c3                   	ret    
 584:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  neg = 0;
 588:	c7 45 bc 00 00 00 00 	movl   $0x0,-0x44(%ebp)
 58f:	eb 87                	jmp    518 <printint+0x28>
 591:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 598:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 59f:	90                   	nop

000005a0 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 5a0:	55                   	push   %ebp
 5a1:	89 e5                	mov    %esp,%ebp
 5a3:	57                   	push   %edi
 5a4:	56                   	push   %esi
 5a5:	53                   	push   %ebx
 5a6:	83 ec 2c             	sub    $0x2c,%esp
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
  for(i = 0; fmt[i]; i++){
 5a9:	8b 5d 0c             	mov    0xc(%ebp),%ebx
{
 5ac:	8b 75 08             	mov    0x8(%ebp),%esi
  for(i = 0; fmt[i]; i++){
 5af:	0f b6 13             	movzbl (%ebx),%edx
 5b2:	84 d2                	test   %dl,%dl
 5b4:	74 6a                	je     620 <printf+0x80>
  ap = (uint*)(void*)&fmt + 1;
 5b6:	8d 45 10             	lea    0x10(%ebp),%eax
 5b9:	83 c3 01             	add    $0x1,%ebx
  write(fd, &c, 1);
 5bc:	8d 7d e7             	lea    -0x19(%ebp),%edi
  state = 0;
 5bf:	31 c9                	xor    %ecx,%ecx
  ap = (uint*)(void*)&fmt + 1;
 5c1:	89 45 d0             	mov    %eax,-0x30(%ebp)
 5c4:	eb 36                	jmp    5fc <printf+0x5c>
 5c6:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 5cd:	8d 76 00             	lea    0x0(%esi),%esi
 5d0:	89 4d d4             	mov    %ecx,-0x2c(%ebp)
    c = fmt[i] & 0xff;
    if(state == 0){
      if(c == '%'){
        state = '%';
 5d3:	b9 25 00 00 00       	mov    $0x25,%ecx
      if(c == '%'){
 5d8:	83 f8 25             	cmp    $0x25,%eax
 5db:	74 15                	je     5f2 <printf+0x52>
  write(fd, &c, 1);
 5dd:	83 ec 04             	sub    $0x4,%esp
 5e0:	88 55 e7             	mov    %dl,-0x19(%ebp)
 5e3:	6a 01                	push   $0x1
 5e5:	57                   	push   %edi
 5e6:	56                   	push   %esi
 5e7:	e8 77 fe ff ff       	call   463 <write>
 5ec:	8b 4d d4             	mov    -0x2c(%ebp),%ecx
      } else {
        putc(fd, c);
 5ef:	83 c4 10             	add    $0x10,%esp
  for(i = 0; fmt[i]; i++){
 5f2:	0f b6 13             	movzbl (%ebx),%edx
 5f5:	83 c3 01             	add    $0x1,%ebx
 5f8:	84 d2                	test   %dl,%dl
 5fa:	74 24                	je     620 <printf+0x80>
    c = fmt[i] & 0xff;
 5fc:	0f b6 c2             	movzbl %dl,%eax
    if(state == 0){
 5ff:	85 c9                	test   %ecx,%ecx
 601:	74 cd                	je     5d0 <printf+0x30>
      }
    } else if(state == '%'){
 603:	83 f9 25             	cmp    $0x25,%ecx
 606:	75 ea                	jne    5f2 <printf+0x52>
      if(c == 'd'){
 608:	83 f8 25             	cmp    $0x25,%eax
 60b:	0f 84 07 01 00 00    	je     718 <printf+0x178>
 611:	83 e8 63             	sub    $0x63,%eax
 614:	83 f8 15             	cmp    $0x15,%eax
 617:	77 17                	ja     630 <printf+0x90>
 619:	ff 24 85 a4 0b 00 00 	jmp    *0xba4(,%eax,4)
        putc(fd, c);
      }
      state = 0;
    }
  }
}
 620:	8d 65 f4             	lea    -0xc(%ebp),%esp
 623:	5b                   	pop    %ebx
 624:	5e                   	pop    %esi
 625:	5f                   	pop    %edi
 626:	5d                   	pop    %ebp
 627:	c3                   	ret    
 628:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 62f:	90                   	nop
  write(fd, &c, 1);
 630:	83 ec 04             	sub    $0x4,%esp
 633:	88 55 d4             	mov    %dl,-0x2c(%ebp)
 636:	6a 01                	push   $0x1
 638:	57                   	push   %edi
 639:	56                   	push   %esi
 63a:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
 63e:	e8 20 fe ff ff       	call   463 <write>
        putc(fd, c);
 643:	0f b6 55 d4          	movzbl -0x2c(%ebp),%edx
  write(fd, &c, 1);
 647:	83 c4 0c             	add    $0xc,%esp
 64a:	88 55 e7             	mov    %dl,-0x19(%ebp)
 64d:	6a 01                	push   $0x1
 64f:	57                   	push   %edi
 650:	56                   	push   %esi
 651:	e8 0d fe ff ff       	call   463 <write>
        putc(fd, c);
 656:	83 c4 10             	add    $0x10,%esp
      state = 0;
 659:	31 c9                	xor    %ecx,%ecx
 65b:	eb 95                	jmp    5f2 <printf+0x52>
 65d:	8d 76 00             	lea    0x0(%esi),%esi
        printint(fd, *ap, 16, 0);
 660:	83 ec 0c             	sub    $0xc,%esp
 663:	b9 10 00 00 00       	mov    $0x10,%ecx
 668:	6a 00                	push   $0x0
 66a:	8b 45 d0             	mov    -0x30(%ebp),%eax
 66d:	8b 10                	mov    (%eax),%edx
 66f:	89 f0                	mov    %esi,%eax
 671:	e8 7a fe ff ff       	call   4f0 <printint>
        ap++;
 676:	83 45 d0 04          	addl   $0x4,-0x30(%ebp)
 67a:	83 c4 10             	add    $0x10,%esp
      state = 0;
 67d:	31 c9                	xor    %ecx,%ecx
 67f:	e9 6e ff ff ff       	jmp    5f2 <printf+0x52>
 684:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
        s = (char*)*ap;
 688:	8b 45 d0             	mov    -0x30(%ebp),%eax
 68b:	8b 10                	mov    (%eax),%edx
        ap++;
 68d:	83 c0 04             	add    $0x4,%eax
 690:	89 45 d0             	mov    %eax,-0x30(%ebp)
        if(s == 0)
 693:	85 d2                	test   %edx,%edx
 695:	0f 84 8d 00 00 00    	je     728 <printf+0x188>
        while(*s != 0){
 69b:	0f b6 02             	movzbl (%edx),%eax
      state = 0;
 69e:	31 c9                	xor    %ecx,%ecx
        while(*s != 0){
 6a0:	84 c0                	test   %al,%al
 6a2:	0f 84 4a ff ff ff    	je     5f2 <printf+0x52>
 6a8:	89 5d d4             	mov    %ebx,-0x2c(%ebp)
 6ab:	89 d3                	mov    %edx,%ebx
 6ad:	8d 76 00             	lea    0x0(%esi),%esi
  write(fd, &c, 1);
 6b0:	83 ec 04             	sub    $0x4,%esp
          s++;
 6b3:	83 c3 01             	add    $0x1,%ebx
 6b6:	88 45 e7             	mov    %al,-0x19(%ebp)
  write(fd, &c, 1);
 6b9:	6a 01                	push   $0x1
 6bb:	57                   	push   %edi
 6bc:	56                   	push   %esi
 6bd:	e8 a1 fd ff ff       	call   463 <write>
        while(*s != 0){
 6c2:	0f b6 03             	movzbl (%ebx),%eax
 6c5:	83 c4 10             	add    $0x10,%esp
 6c8:	84 c0                	test   %al,%al
 6ca:	75 e4                	jne    6b0 <printf+0x110>
      state = 0;
 6cc:	8b 5d d4             	mov    -0x2c(%ebp),%ebx
 6cf:	31 c9                	xor    %ecx,%ecx
 6d1:	e9 1c ff ff ff       	jmp    5f2 <printf+0x52>
 6d6:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 6dd:	8d 76 00             	lea    0x0(%esi),%esi
        printint(fd, *ap, 10, 1);
 6e0:	83 ec 0c             	sub    $0xc,%esp
 6e3:	b9 0a 00 00 00       	mov    $0xa,%ecx
 6e8:	6a 01                	push   $0x1
 6ea:	e9 7b ff ff ff       	jmp    66a <printf+0xca>
 6ef:	90                   	nop
        putc(fd, *ap);
 6f0:	8b 45 d0             	mov    -0x30(%ebp),%eax
  write(fd, &c, 1);
 6f3:	83 ec 04             	sub    $0x4,%esp
        putc(fd, *ap);
 6f6:	8b 00                	mov    (%eax),%eax
  write(fd, &c, 1);
 6f8:	6a 01                	push   $0x1
 6fa:	57                   	push   %edi
 6fb:	56                   	push   %esi
        putc(fd, *ap);
 6fc:	88 45 e7             	mov    %al,-0x19(%ebp)
  write(fd, &c, 1);
 6ff:	e8 5f fd ff ff       	call   463 <write>
        ap++;
 704:	83 45 d0 04          	addl   $0x4,-0x30(%ebp)
 708:	83 c4 10             	add    $0x10,%esp
      state = 0;
 70b:	31 c9                	xor    %ecx,%ecx
 70d:	e9 e0 fe ff ff       	jmp    5f2 <printf+0x52>
 712:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
        putc(fd, c);
 718:	88 55 e7             	mov    %dl,-0x19(%ebp)
  write(fd, &c, 1);
 71b:	83 ec 04             	sub    $0x4,%esp
 71e:	e9 2a ff ff ff       	jmp    64d <printf+0xad>
 723:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
 727:	90                   	nop
          s = "(null)";
 728:	ba 9b 0b 00 00       	mov    $0xb9b,%edx
        while(*s != 0){
 72d:	89 5d d4             	mov    %ebx,-0x2c(%ebp)
 730:	b8 28 00 00 00       	mov    $0x28,%eax
 735:	89 d3                	mov    %edx,%ebx
 737:	e9 74 ff ff ff       	jmp    6b0 <printf+0x110>
 73c:	66 90                	xchg   %ax,%ax
 73e:	66 90                	xchg   %ax,%ax

00000740 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 740:	55                   	push   %ebp
  Header *bp, *p;

  bp = (Header*)ap - 1;
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 741:	a1 80 10 00 00       	mov    0x1080,%eax
{
 746:	89 e5                	mov    %esp,%ebp
 748:	57                   	push   %edi
 749:	56                   	push   %esi
 74a:	53                   	push   %ebx
 74b:	8b 5d 08             	mov    0x8(%ebp),%ebx
  bp = (Header*)ap - 1;
 74e:	8d 4b f8             	lea    -0x8(%ebx),%ecx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 751:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 758:	89 c2                	mov    %eax,%edx
 75a:	8b 00                	mov    (%eax),%eax
 75c:	39 ca                	cmp    %ecx,%edx
 75e:	73 30                	jae    790 <free+0x50>
 760:	39 c1                	cmp    %eax,%ecx
 762:	72 04                	jb     768 <free+0x28>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 764:	39 c2                	cmp    %eax,%edx
 766:	72 f0                	jb     758 <free+0x18>
      break;
  if(bp + bp->s.size == p->s.ptr){
 768:	8b 73 fc             	mov    -0x4(%ebx),%esi
 76b:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 76e:	39 f8                	cmp    %edi,%eax
 770:	74 30                	je     7a2 <free+0x62>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 772:	89 43 f8             	mov    %eax,-0x8(%ebx)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 775:	8b 42 04             	mov    0x4(%edx),%eax
 778:	8d 34 c2             	lea    (%edx,%eax,8),%esi
 77b:	39 f1                	cmp    %esi,%ecx
 77d:	74 3a                	je     7b9 <free+0x79>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 77f:	89 0a                	mov    %ecx,(%edx)
  } else
    p->s.ptr = bp;
  freep = p;
}
 781:	5b                   	pop    %ebx
  freep = p;
 782:	89 15 80 10 00 00    	mov    %edx,0x1080
}
 788:	5e                   	pop    %esi
 789:	5f                   	pop    %edi
 78a:	5d                   	pop    %ebp
 78b:	c3                   	ret    
 78c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 790:	39 c2                	cmp    %eax,%edx
 792:	72 c4                	jb     758 <free+0x18>
 794:	39 c1                	cmp    %eax,%ecx
 796:	73 c0                	jae    758 <free+0x18>
  if(bp + bp->s.size == p->s.ptr){
 798:	8b 73 fc             	mov    -0x4(%ebx),%esi
 79b:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 79e:	39 f8                	cmp    %edi,%eax
 7a0:	75 d0                	jne    772 <free+0x32>
    bp->s.size += p->s.ptr->s.size;
 7a2:	03 70 04             	add    0x4(%eax),%esi
 7a5:	89 73 fc             	mov    %esi,-0x4(%ebx)
    bp->s.ptr = p->s.ptr->s.ptr;
 7a8:	8b 02                	mov    (%edx),%eax
 7aa:	8b 00                	mov    (%eax),%eax
 7ac:	89 43 f8             	mov    %eax,-0x8(%ebx)
  if(p + p->s.size == bp){
 7af:	8b 42 04             	mov    0x4(%edx),%eax
 7b2:	8d 34 c2             	lea    (%edx,%eax,8),%esi
 7b5:	39 f1                	cmp    %esi,%ecx
 7b7:	75 c6                	jne    77f <free+0x3f>
    p->s.size += bp->s.size;
 7b9:	03 43 fc             	add    -0x4(%ebx),%eax
  freep = p;
 7bc:	89 15 80 10 00 00    	mov    %edx,0x1080
    p->s.size += bp->s.size;
 7c2:	89 42 04             	mov    %eax,0x4(%edx)
    p->s.ptr = bp->s.ptr;
 7c5:	8b 4b f8             	mov    -0x8(%ebx),%ecx
 7c8:	89 0a                	mov    %ecx,(%edx)
}
 7ca:	5b                   	pop    %ebx
 7cb:	5e                   	pop    %esi
 7cc:	5f                   	pop    %edi
 7cd:	5d                   	pop    %ebp
 7ce:	c3                   	ret    
 7cf:	90                   	nop

000007d0 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 7d0:	55                   	push   %ebp
 7d1:	89 e5                	mov    %esp,%ebp
 7d3:	57                   	push   %edi
 7d4:	56                   	push   %esi
 7d5:	53                   	push   %ebx
 7d6:	83 ec 1c             	sub    $0x1c,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 7d9:	8b 45 08             	mov    0x8(%ebp),%eax
  if((prevp = freep) == 0){
 7dc:	8b 3d 80 10 00 00    	mov    0x1080,%edi
  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 7e2:	8d 70 07             	lea    0x7(%eax),%esi
 7e5:	c1 ee 03             	shr    $0x3,%esi
 7e8:	83 c6 01             	add    $0x1,%esi
  if((prevp = freep) == 0){
 7eb:	85 ff                	test   %edi,%edi
 7ed:	0f 84 9d 00 00 00    	je     890 <malloc+0xc0>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 7f3:	8b 17                	mov    (%edi),%edx
    if(p->s.size >= nunits){
 7f5:	8b 4a 04             	mov    0x4(%edx),%ecx
 7f8:	39 f1                	cmp    %esi,%ecx
 7fa:	73 6a                	jae    866 <malloc+0x96>
 7fc:	bb 00 10 00 00       	mov    $0x1000,%ebx
 801:	39 de                	cmp    %ebx,%esi
 803:	0f 43 de             	cmovae %esi,%ebx
  p = sbrk(nu * sizeof(Header));
 806:	8d 04 dd 00 00 00 00 	lea    0x0(,%ebx,8),%eax
 80d:	89 45 e4             	mov    %eax,-0x1c(%ebp)
 810:	eb 17                	jmp    829 <malloc+0x59>
 812:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 818:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 81a:	8b 48 04             	mov    0x4(%eax),%ecx
 81d:	39 f1                	cmp    %esi,%ecx
 81f:	73 4f                	jae    870 <malloc+0xa0>
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 821:	8b 3d 80 10 00 00    	mov    0x1080,%edi
 827:	89 c2                	mov    %eax,%edx
 829:	39 d7                	cmp    %edx,%edi
 82b:	75 eb                	jne    818 <malloc+0x48>
  p = sbrk(nu * sizeof(Header));
 82d:	83 ec 0c             	sub    $0xc,%esp
 830:	ff 75 e4             	push   -0x1c(%ebp)
 833:	e8 93 fc ff ff       	call   4cb <sbrk>
  if(p == (char*)-1)
 838:	83 c4 10             	add    $0x10,%esp
 83b:	83 f8 ff             	cmp    $0xffffffff,%eax
 83e:	74 1c                	je     85c <malloc+0x8c>
  hp->s.size = nu;
 840:	89 58 04             	mov    %ebx,0x4(%eax)
  free((void*)(hp + 1));
 843:	83 ec 0c             	sub    $0xc,%esp
 846:	83 c0 08             	add    $0x8,%eax
 849:	50                   	push   %eax
 84a:	e8 f1 fe ff ff       	call   740 <free>
  return freep;
 84f:	8b 15 80 10 00 00    	mov    0x1080,%edx
      if((p = morecore(nunits)) == 0)
 855:	83 c4 10             	add    $0x10,%esp
 858:	85 d2                	test   %edx,%edx
 85a:	75 bc                	jne    818 <malloc+0x48>
        return 0;
  }
}
 85c:	8d 65 f4             	lea    -0xc(%ebp),%esp
        return 0;
 85f:	31 c0                	xor    %eax,%eax
}
 861:	5b                   	pop    %ebx
 862:	5e                   	pop    %esi
 863:	5f                   	pop    %edi
 864:	5d                   	pop    %ebp
 865:	c3                   	ret    
    if(p->s.size >= nunits){
 866:	89 d0                	mov    %edx,%eax
 868:	89 fa                	mov    %edi,%edx
 86a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      if(p->s.size == nunits)
 870:	39 ce                	cmp    %ecx,%esi
 872:	74 4c                	je     8c0 <malloc+0xf0>
        p->s.size -= nunits;
 874:	29 f1                	sub    %esi,%ecx
 876:	89 48 04             	mov    %ecx,0x4(%eax)
        p += p->s.size;
 879:	8d 04 c8             	lea    (%eax,%ecx,8),%eax
        p->s.size = nunits;
 87c:	89 70 04             	mov    %esi,0x4(%eax)
      freep = prevp;
 87f:	89 15 80 10 00 00    	mov    %edx,0x1080
}
 885:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return (void*)(p + 1);
 888:	83 c0 08             	add    $0x8,%eax
}
 88b:	5b                   	pop    %ebx
 88c:	5e                   	pop    %esi
 88d:	5f                   	pop    %edi
 88e:	5d                   	pop    %ebp
 88f:	c3                   	ret    
    base.s.ptr = freep = prevp = &base;
 890:	c7 05 80 10 00 00 84 	movl   $0x1084,0x1080
 897:	10 00 00 
    base.s.size = 0;
 89a:	bf 84 10 00 00       	mov    $0x1084,%edi
    base.s.ptr = freep = prevp = &base;
 89f:	c7 05 84 10 00 00 84 	movl   $0x1084,0x1084
 8a6:	10 00 00 
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 8a9:	89 fa                	mov    %edi,%edx
    base.s.size = 0;
 8ab:	c7 05 88 10 00 00 00 	movl   $0x0,0x1088
 8b2:	00 00 00 
    if(p->s.size >= nunits){
 8b5:	e9 42 ff ff ff       	jmp    7fc <malloc+0x2c>
 8ba:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
        prevp->s.ptr = p->s.ptr;
 8c0:	8b 08                	mov    (%eax),%ecx
 8c2:	89 0a                	mov    %ecx,(%edx)
 8c4:	eb b9                	jmp    87f <malloc+0xaf>
 8c6:	66 90                	xchg   %ax,%ax
 8c8:	66 90                	xchg   %ax,%ax
 8ca:	66 90                	xchg   %ax,%ax
 8cc:	66 90                	xchg   %ax,%ax
 8ce:	66 90                	xchg   %ax,%ax

000008d0 <thread_init>:
  thread_yield();
}

void thread_init(void) {
  // Initialize the main thread
  current_thread = &threads[0];
 8d0:	c7 05 a0 10 00 00 c0 	movl   $0x10c0,0x10a0
 8d7:	10 00 00 
  current_thread->tid = 0;
 8da:	c7 05 c0 10 00 00 00 	movl   $0x0,0x10c0
 8e1:	00 00 00 
  current_thread->state = RUNNING;
 8e4:	c7 05 c4 10 00 00 02 	movl   $0x2,0x10c4
 8eb:	00 00 00 
}
 8ee:	c3                   	ret    
 8ef:	90                   	nop

000008f0 <thread_create>:

tid_t thread_create(void (*fn)(void*), void *arg) {
  struct thread *t = 0;
  
  // Find a FREE thread slot
  for (int i = 0; i < MAX_THREADS; i++) {
 8f0:	ba c4 10 00 00       	mov    $0x10c4,%edx
 8f5:	31 c0                	xor    %eax,%eax
 8f7:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 8fe:	66 90                	xchg   %ax,%ax
    if (threads[i].state == FREE) {
 900:	8b 0a                	mov    (%edx),%ecx
 902:	85 c9                	test   %ecx,%ecx
 904:	74 1a                	je     920 <thread_create+0x30>
  for (int i = 0; i < MAX_THREADS; i++) {
 906:	83 c0 01             	add    $0x1,%eax
 909:	81 c2 14 10 00 00    	add    $0x1014,%edx
 90f:	83 f8 08             	cmp    $0x8,%eax
 912:	75 ec                	jne    900 <thread_create+0x10>
      t = &threads[i];
      break;
    }
  }
  
  if (!t) return -1; // No available threads
 914:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  // Initialize the context to 0, and set the instruction pointer to the stub
  memset(t->context, 0, sizeof(struct context));
  t->context->eip = (uint)thread_stub;
  
  return t->tid;
}
 919:	c3                   	ret    
 91a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
tid_t thread_create(void (*fn)(void*), void *arg) {
 920:	55                   	push   %ebp
  t->tid = next_tid++;
 921:	8b 15 34 10 00 00    	mov    0x1034,%edx
 927:	8d 4a 01             	lea    0x1(%edx),%ecx
tid_t thread_create(void (*fn)(void*), void *arg) {
 92a:	89 e5                	mov    %esp,%ebp
 92c:	56                   	push   %esi
 92d:	53                   	push   %ebx
  t->tid = next_tid++;
 92e:	69 d8 14 10 00 00    	imul   $0x1014,%eax,%ebx
  t->fn = fn;
 934:	8b 45 08             	mov    0x8(%ebp),%eax
  t->tid = next_tid++;
 937:	89 0d 34 10 00 00    	mov    %ecx,0x1034
  t->fn = fn;
 93d:	89 83 cc 20 00 00    	mov    %eax,0x20cc(%ebx)
  t->arg = arg;
 943:	8b 45 0c             	mov    0xc(%ebp),%eax
  memset(t->context, 0, sizeof(struct context));
 946:	83 ec 04             	sub    $0x4,%esp
 949:	6a 14                	push   $0x14
  t->arg = arg;
 94b:	89 83 d0 20 00 00    	mov    %eax,0x20d0(%ebx)
  sp -= sizeof(struct context);
 951:	8d 83 b4 20 00 00    	lea    0x20b4(%ebx),%eax
  memset(t->context, 0, sizeof(struct context));
 957:	6a 00                	push   $0x0
 959:	50                   	push   %eax
  t->tid = next_tid++;
 95a:	89 93 c0 10 00 00    	mov    %edx,0x10c0(%ebx)
  t->state = RUNNABLE;
 960:	c7 83 c4 10 00 00 01 	movl   $0x1,0x10c4(%ebx)
 967:	00 00 00 
  t->context = (struct context*)sp;
 96a:	89 83 c8 20 00 00    	mov    %eax,0x20c8(%ebx)
  memset(t->context, 0, sizeof(struct context));
 970:	e8 3b f9 ff ff       	call   2b0 <memset>
  t->context->eip = (uint)thread_stub;
 975:	8b 83 c8 20 00 00    	mov    0x20c8(%ebx),%eax
  return t->tid;
 97b:	83 c4 10             	add    $0x10,%esp
  t->context->eip = (uint)thread_stub;
 97e:	c7 40 10 40 0a 00 00 	movl   $0xa40,0x10(%eax)
  return t->tid;
 985:	8b 83 c0 10 00 00    	mov    0x10c0(%ebx),%eax
}
 98b:	8d 65 f8             	lea    -0x8(%ebp),%esp
 98e:	5b                   	pop    %ebx
 98f:	5e                   	pop    %esi
 990:	5d                   	pop    %ebp
 991:	c3                   	ret    
 992:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 999:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

000009a0 <thread_yield>:

void thread_yield(void) {
 9a0:	55                   	push   %ebp
 9a1:	89 e5                	mov    %esp,%ebp
 9a3:	57                   	push   %edi
 9a4:	56                   	push   %esi
 9a5:	53                   	push   %ebx
 9a6:	83 ec 0c             	sub    $0xc,%esp
  struct thread *old_thread = current_thread;
 9a9:	8b 1d a0 10 00 00    	mov    0x10a0,%ebx
  
  // Mark current thread as RUNNABLE if it's not a ZOMBIE
  if (old_thread->state == RUNNING) {
 9af:	83 7b 04 02          	cmpl   $0x2,0x4(%ebx)
 9b3:	75 07                	jne    9bc <thread_yield+0x1c>
    old_thread->state = RUNNABLE;
 9b5:	c7 43 04 01 00 00 00 	movl   $0x1,0x4(%ebx)
  }
  
  // Round-robin scheduler to pick next RUNNABLE thread
  int i = (old_thread - threads + 1) % MAX_THREADS;
 9bc:	89 d9                	mov    %ebx,%ecx
 9be:	81 e9 c0 10 00 00    	sub    $0x10c0,%ecx
 9c4:	c1 f9 02             	sar    $0x2,%ecx
 9c7:	69 c9 cd 28 ac dc    	imul   $0xdcac28cd,%ecx,%ecx
 9cd:	8d 41 01             	lea    0x1(%ecx),%eax
 9d0:	eb 1e                	jmp    9f0 <thread_yield+0x50>
 9d2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  while (i != (old_thread - threads)) {
    if (threads[i].state == RUNNABLE) {
 9d8:	69 d0 14 10 00 00    	imul   $0x1014,%eax,%edx
 9de:	83 ba c4 10 00 00 01 	cmpl   $0x1,0x10c4(%edx)
 9e5:	8d b2 c0 10 00 00    	lea    0x10c0(%edx),%esi
 9eb:	74 23                	je     a10 <thread_yield+0x70>
      current_thread = &threads[i];
      current_thread->state = RUNNING;
      uswtch(&old_thread->context, current_thread->context);
      return;
    }
    i = (i + 1) % MAX_THREADS;
 9ed:	83 c0 01             	add    $0x1,%eax
  int i = (old_thread - threads + 1) % MAX_THREADS;
 9f0:	99                   	cltd   
 9f1:	c1 ea 1d             	shr    $0x1d,%edx
 9f4:	01 d0                	add    %edx,%eax
 9f6:	83 e0 07             	and    $0x7,%eax
 9f9:	29 d0                	sub    %edx,%eax
  while (i != (old_thread - threads)) {
 9fb:	39 c1                	cmp    %eax,%ecx
 9fd:	75 d9                	jne    9d8 <thread_yield+0x38>
  }
}
 9ff:	8d 65 f4             	lea    -0xc(%ebp),%esp
 a02:	5b                   	pop    %ebx
 a03:	5e                   	pop    %esi
 a04:	5f                   	pop    %edi
 a05:	5d                   	pop    %ebp
 a06:	c3                   	ret    
 a07:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 a0e:	66 90                	xchg   %ax,%ax
      uswtch(&old_thread->context, current_thread->context);
 a10:	83 ec 08             	sub    $0x8,%esp
 a13:	81 c3 08 10 00 00    	add    $0x1008,%ebx
 a19:	ff b2 c8 20 00 00    	push   0x20c8(%edx)
 a1f:	53                   	push   %ebx
      current_thread = &threads[i];
 a20:	89 35 a0 10 00 00    	mov    %esi,0x10a0
      current_thread->state = RUNNING;
 a26:	c7 82 c4 10 00 00 02 	movl   $0x2,0x10c4(%edx)
 a2d:	00 00 00 
      uswtch(&old_thread->context, current_thread->context);
 a30:	e8 09 01 00 00       	call   b3e <uswtch>
      return;
 a35:	83 c4 10             	add    $0x10,%esp
}
 a38:	8d 65 f4             	lea    -0xc(%ebp),%esp
 a3b:	5b                   	pop    %ebx
 a3c:	5e                   	pop    %esi
 a3d:	5f                   	pop    %edi
 a3e:	5d                   	pop    %ebp
 a3f:	c3                   	ret    

00000a40 <thread_stub>:
static void thread_stub(void) {
 a40:	55                   	push   %ebp
 a41:	89 e5                	mov    %esp,%ebp
 a43:	83 ec 14             	sub    $0x14,%esp
  current_thread->fn(current_thread->arg);
 a46:	a1 a0 10 00 00       	mov    0x10a0,%eax
 a4b:	ff b0 10 10 00 00    	push   0x1010(%eax)
 a51:	ff 90 0c 10 00 00    	call   *0x100c(%eax)
  current_thread->state = ZOMBIE;
 a57:	a1 a0 10 00 00       	mov    0x10a0,%eax
  thread_yield();
 a5c:	83 c4 10             	add    $0x10,%esp
  current_thread->state = ZOMBIE;
 a5f:	c7 40 04 03 00 00 00 	movl   $0x3,0x4(%eax)
}
 a66:	c9                   	leave  
  thread_yield();
 a67:	e9 34 ff ff ff       	jmp    9a0 <thread_yield>
 a6c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000a70 <thread_join>:

int thread_join(tid_t tid) {
 a70:	55                   	push   %ebp
 a71:	b8 c0 10 00 00       	mov    $0x10c0,%eax
 a76:	89 e5                	mov    %esp,%ebp
 a78:	56                   	push   %esi
 a79:	8b 55 08             	mov    0x8(%ebp),%edx
 a7c:	53                   	push   %ebx
  struct thread *t = 0;
  
  // Locate the thread by ID
  for (int i = 0; i < MAX_THREADS; i++) {
 a7d:	31 db                	xor    %ebx,%ebx
 a7f:	eb 14                	jmp    a95 <thread_join+0x25>
 a81:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 a88:	83 c3 01             	add    $0x1,%ebx
 a8b:	05 14 10 00 00       	add    $0x1014,%eax
 a90:	83 fb 08             	cmp    $0x8,%ebx
 a93:	74 4b                	je     ae0 <thread_join+0x70>
    if (threads[i].tid == tid && threads[i].state != FREE) {
 a95:	39 10                	cmp    %edx,(%eax)
 a97:	75 ef                	jne    a88 <thread_join+0x18>
 a99:	8b 48 04             	mov    0x4(%eax),%ecx
 a9c:	85 c9                	test   %ecx,%ecx
 a9e:	74 e8                	je     a88 <thread_join+0x18>
  }
  
  if (!t) return -1;
  
  // Cooperatively yield until the target thread becomes a ZOMBIE
  while (t->state != ZOMBIE) {
 aa0:	83 f9 03             	cmp    $0x3,%ecx
 aa3:	74 1e                	je     ac3 <thread_join+0x53>
 aa5:	69 f3 14 10 00 00    	imul   $0x1014,%ebx,%esi
 aab:	81 c6 c0 10 00 00    	add    $0x10c0,%esi
 ab1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    thread_yield();
 ab8:	e8 e3 fe ff ff       	call   9a0 <thread_yield>
  while (t->state != ZOMBIE) {
 abd:	83 7e 04 03          	cmpl   $0x3,0x4(%esi)
 ac1:	75 f5                	jne    ab8 <thread_join+0x48>
  }
  
  // Clean up the ZOMBIE thread
  t->state = FREE;
 ac3:	69 db 14 10 00 00    	imul   $0x1014,%ebx,%ebx
  return 0;
 ac9:	31 c0                	xor    %eax,%eax
  t->state = FREE;
 acb:	c7 83 c4 10 00 00 00 	movl   $0x0,0x10c4(%ebx)
 ad2:	00 00 00 
 ad5:	5b                   	pop    %ebx
 ad6:	5e                   	pop    %esi
 ad7:	5d                   	pop    %ebp
 ad8:	c3                   	ret    
 ad9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 ae0:	5b                   	pop    %ebx
  if (!t) return -1;
 ae1:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
 ae6:	5e                   	pop    %esi
 ae7:	5d                   	pop    %ebp
 ae8:	c3                   	ret    
 ae9:	66 90                	xchg   %ax,%ax
 aeb:	66 90                	xchg   %ax,%ax
 aed:	66 90                	xchg   %ax,%ax
 aef:	90                   	nop

00000af0 <mutex_init>:
#include "stat.h"
#include "user.h"
#include "uthread.h"
#include "umutex.h"

void mutex_init(umutex_t *m){ m->locked = 0; }
 af0:	55                   	push   %ebp
 af1:	89 e5                	mov    %esp,%ebp
 af3:	8b 45 08             	mov    0x8(%ebp),%eax
 af6:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
 afc:	5d                   	pop    %ebp
 afd:	c3                   	ret    
 afe:	66 90                	xchg   %ax,%ax

00000b00 <mutex_lock>:
void mutex_lock(umutex_t *m){ while(m->locked){ thread_yield(); } m->locked = 1; }
 b00:	55                   	push   %ebp
 b01:	89 e5                	mov    %esp,%ebp
 b03:	53                   	push   %ebx
 b04:	83 ec 04             	sub    $0x4,%esp
 b07:	8b 5d 08             	mov    0x8(%ebp),%ebx
 b0a:	8b 03                	mov    (%ebx),%eax
 b0c:	85 c0                	test   %eax,%eax
 b0e:	74 0b                	je     b1b <mutex_lock+0x1b>
 b10:	e8 8b fe ff ff       	call   9a0 <thread_yield>
 b15:	8b 03                	mov    (%ebx),%eax
 b17:	85 c0                	test   %eax,%eax
 b19:	75 f5                	jne    b10 <mutex_lock+0x10>
 b1b:	c7 03 01 00 00 00    	movl   $0x1,(%ebx)
 b21:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 b24:	c9                   	leave  
 b25:	c3                   	ret    
 b26:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 b2d:	8d 76 00             	lea    0x0(%esi),%esi

00000b30 <mutex_unlock>:
 b30:	55                   	push   %ebp
 b31:	89 e5                	mov    %esp,%ebp
 b33:	8b 45 08             	mov    0x8(%ebp),%eax
 b36:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
 b3c:	5d                   	pop    %ebp
 b3d:	c3                   	ret    

00000b3e <uswtch>:
# User-space context switch for xv6 x86
# void uswtch(struct context **old, struct context *new);

.globl uswtch
uswtch:
  movl 4(%esp), %eax
 b3e:	8b 44 24 04          	mov    0x4(%esp),%eax
  movl 8(%esp), %edx
 b42:	8b 54 24 08          	mov    0x8(%esp),%edx

  pushl %ebp
 b46:	55                   	push   %ebp
  pushl %ebx
 b47:	53                   	push   %ebx
  pushl %esi
 b48:	56                   	push   %esi
  pushl %edi
 b49:	57                   	push   %edi

  movl %esp, (%eax)
 b4a:	89 20                	mov    %esp,(%eax)
  movl %edx, %esp
 b4c:	89 d4                	mov    %edx,%esp

  popl %edi
 b4e:	5f                   	pop    %edi
  popl %esi
 b4f:	5e                   	pop    %esi
  popl %ebx
 b50:	5b                   	pop    %ebx
  popl %ebp
 b51:	5d                   	pop    %ebp
  ret
 b52:	c3                   	ret    
