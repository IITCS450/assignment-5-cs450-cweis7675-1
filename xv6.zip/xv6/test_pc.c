#include "types.h"
#include "stat.h"
#include "user.h"
#include "uthread.h"
#include "umutex.h"

#define N 8
static int buf[N], head, tail, count;
static umutex_t mu;

static void producer(void *arg){
  int id = (int)arg;
  for(int i=0;i<100;i++){
    // Keep trying to insert the item until there is space
    while(1){
      mutex_lock(&mu);
      if(count < N){
        buf[tail] = id*1000 + i;
        tail = (tail+1)%N;
        count++;
        mutex_unlock(&mu);
        break; // Successfully inserted, break the retry loop!
      }
      mutex_unlock(&mu);
      thread_yield(); // Buffer full, yield and try again
    }
    // Yield fairly after producing an item
    thread_yield();
  }
}

static void consumer(void *arg){
  (void)arg;
  int got = 0;
  while(got < 200){
    // Keep trying to consume an item until one is available
    while(1){
      mutex_lock(&mu);
      if(count > 0){
        int x = buf[head];
        head = (head+1)%N;
        count--;
        got++;
        if(got % 50 == 0) printf(1, "consumer got %d (last=%d)\n", got, x);
        mutex_unlock(&mu);
        break; // Successfully consumed, break the retry loop!
      }
      mutex_unlock(&mu);
      thread_yield(); // Buffer empty, yield and try again
    }
    // Yield fairly after consuming an item
    thread_yield();
  }
}

int main(int argc, char *argv[])
{
  printf(1, "Starting test...\n");

  thread_init();
  mutex_init(&mu);

  tid_t prod1_tid = thread_create(producer, (void*)1);
  tid_t prod2_tid = thread_create(producer, (void*)2);
  
  tid_t cons_tid = thread_create(consumer, (void*)3);

  thread_join(prod1_tid);
  thread_join(prod2_tid);
  thread_join(cons_tid);

  printf(1, "test_pc: test successful\n");
  
  exit();
}