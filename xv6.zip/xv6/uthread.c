#include "types.h"
#include "stat.h"
#include "user.h"
#include "uthread.h"

#define MAX_THREADS 8
#define STACK_SIZE  4096

// Thread states
enum tstate { FREE, RUNNABLE, RUNNING, ZOMBIE };

// Saved registers for context switches
struct context {
  uint edi;
  uint esi;
  uint ebx;
  uint ebp;
  uint eip;
};

extern void uswtch(struct context **old, struct context *new);

// Thread Control Block
struct thread {
  int tid;
  enum tstate state;
  char stack[STACK_SIZE];
  struct context *context;
  void (*fn)(void*);
  void *arg;
};

static struct thread threads[MAX_THREADS];
static struct thread *current_thread;
static int next_tid = 1;

// Wrapper function to execute the thread
static void thread_stub(void) {
  current_thread->fn(current_thread->arg);
  current_thread->state = ZOMBIE;
  thread_yield();
}

void thread_init(void) {
  // Initialize the main thread
  current_thread = &threads[0];
  current_thread->tid = 0;
  current_thread->state = RUNNING;
}

tid_t thread_create(void (*fn)(void*), void *arg) {
  struct thread *t = 0;
  
  // Find a FREE thread slot
  for (int i = 0; i < MAX_THREADS; i++) {
    if (threads[i].state == FREE) {
      t = &threads[i];
      break;
    }
  }
  
  if (!t) return -1; // No available threads
  
  t->tid = next_tid++;
  t->state = RUNNABLE;
  t->fn = fn;
  t->arg = arg;
  
  // Setup the stack for the context switch
  char *sp = t->stack + STACK_SIZE;
  sp -= sizeof(struct context);
  t->context = (struct context*)sp;
  
  // Initialize the context to 0, and set the instruction pointer to the stub
  memset(t->context, 0, sizeof(struct context));
  t->context->eip = (uint)thread_stub;
  
  return t->tid;
}

void thread_yield(void) {
  struct thread *old_thread = current_thread;
  
  // Mark current thread as RUNNABLE if it's not a ZOMBIE
  if (old_thread->state == RUNNING) {
    old_thread->state = RUNNABLE;
  }
  
  // Round-robin scheduler to pick next RUNNABLE thread
  int i = (old_thread - threads + 1) % MAX_THREADS;
  while (i != (old_thread - threads)) {
    if (threads[i].state == RUNNABLE) {
      current_thread = &threads[i];
      current_thread->state = RUNNING;
      uswtch(&old_thread->context, current_thread->context);
      return;
    }
    i = (i + 1) % MAX_THREADS;
  }
}

int thread_join(tid_t tid) {
  struct thread *t = 0;
  
  // Locate the thread by ID
  for (int i = 0; i < MAX_THREADS; i++) {
    if (threads[i].tid == tid && threads[i].state != FREE) {
      t = &threads[i];
      break;
    }
  }
  
  if (!t) return -1;
  
  // Cooperatively yield until the target thread becomes a ZOMBIE
  while (t->state != ZOMBIE) {
    thread_yield();
  }
  
  // Clean up the ZOMBIE thread
  t->state = FREE;
  return 0;
}